"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  models/appointment.py — Appointment domain model                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass


@dataclass
class Appointment:
    """Domain Model — Appointment entity. OOP: Encapsulation + Abstraction."""
    appointment_id: str
    patient_id:     str
    doctor_id:      str
    date:           str
    time:           str
    reason:         str
    appt_type:      str
    status:         str
    created_at:     str

    @staticmethod
    def from_dict(d: dict) -> "Appointment":
        return Appointment(
            appointment_id = d.get("appointment_id", ""),
            patient_id     = d.get("patient_id", ""),
            doctor_id      = d.get("doctor_id", ""),
            date           = d.get("date", ""),
            time           = d.get("time", ""),
            reason         = d.get("reason", ""),
            appt_type      = d.get("appt_type", ""),
            status         = d.get("status", "Scheduled"),
            created_at     = d.get("created_at", ""),
        )
