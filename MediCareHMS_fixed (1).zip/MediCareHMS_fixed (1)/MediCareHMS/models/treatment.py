"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  models/treatment.py — Treatment domain model                               ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts:
  - Encapsulation: All treatment fields bundled in one object.
  - Abstraction: from_dict() factory hides raw DB row conversion.
  - SRP: This class only represents a Treatment entity. No DB logic.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class Treatment:
    """
    Domain Model — represents a single Treatment record.

    OOP → Encapsulation:
      All fields (diagnosis, medication, lab, pharmacy, ward, cost)
      are grouped in one object. No one passes raw dicts around.

    OOP → Abstraction:
      from_dict() is a factory method — callers don't know how
      raw DB data becomes a Treatment object.
    """
    treatment_id:   str
    patient_id:     str
    doctor_id:      str
    diagnosis:      str
    medication:     str
    lab_tests:      str
    pharmacy_items: str
    ward:           str
    notes:          str
    treatment_cost: float
    date:           str

    # Optional join fields (populated by repository JOIN queries)
    patient_name:   Optional[str] = None
    doctor_name:    Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "Treatment":
        """
        Factory method: creates Treatment from a DB row dict.
        Abstraction — hides dict-to-object conversion from callers.
        """
        return Treatment(
            treatment_id   = d.get("treatment_id", ""),
            patient_id     = d.get("patient_id", ""),
            doctor_id      = d.get("doctor_id", ""),
            diagnosis      = d.get("diagnosis", ""),
            medication     = d.get("medication", "") or "",
            lab_tests      = d.get("lab_tests", "") or "",
            pharmacy_items = d.get("pharmacy_items", "") or "",
            ward           = d.get("ward", "") or "",
            notes          = d.get("notes", "") or "",
            treatment_cost = float(d.get("treatment_cost", 0) or 0),
            date           = d.get("date", ""),
            patient_name   = d.get("patient_name"),
            doctor_name    = d.get("doctor_name"),
        )

    def to_dict(self) -> dict:
        """Convert back to dict for DB operations."""
        return {
            "treatment_id":   self.treatment_id,
            "patient_id":     self.patient_id,
            "doctor_id":      self.doctor_id,
            "diagnosis":      self.diagnosis,
            "medication":     self.medication,
            "lab_tests":      self.lab_tests,
            "pharmacy_items": self.pharmacy_items,
            "ward":           self.ward,
            "notes":          self.notes,
            "treatment_cost": self.treatment_cost,
            "date":           self.date,
        }

    def summary(self) -> str:
        """
        Returns a human-readable one-line summary of this treatment.
        Clean Code: meaningful helper instead of formatting in the UI layer.
        """
        return (f"[{self.treatment_id}] {self.diagnosis} — "
                f"LKR {self.treatment_cost:,.2f} ({self.date})")
