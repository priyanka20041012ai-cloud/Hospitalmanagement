"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  models/bill.py — Bill domain model                                         ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP: Encapsulation + Abstraction. Same pattern as Patient/Doctor models.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class Bill:
    """
    Domain Model — represents a billing record.

    OOP → Encapsulation: All billing fields in one object.
    Clean Code: calculate_subtotal() is a pure method — no side effects.
    """
    bill_id:          str
    patient_id:       str
    treatment_id:     str
    doctor_id:        str
    consultation_fee: float
    treatment_cost:   float
    lab_fee:          float
    pharmacy_cost:    float
    ward_fee:         float
    tax:              float
    total:            float
    payment_method:   str
    status:           str
    date:             str

    # Optional join fields
    patient_name:   Optional[str] = None
    doctor_name:    Optional[str] = None
    diagnosis:      Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "Bill":
        """Factory method — creates Bill from DB row dict."""
        return Bill(
            bill_id          = d.get("bill_id", ""),
            patient_id       = d.get("patient_id", ""),
            treatment_id     = d.get("treatment_id", ""),
            doctor_id        = d.get("doctor_id", ""),
            consultation_fee = float(d.get("consultation_fee", 0) or 0),
            treatment_cost   = float(d.get("treatment_cost", 0) or 0),
            lab_fee          = float(d.get("lab_fee", 0) or 0),
            pharmacy_cost    = float(d.get("pharmacy_cost", 0) or 0),
            ward_fee         = float(d.get("ward_fee", 0) or 0),
            tax              = float(d.get("tax", 0) or 0),
            total            = float(d.get("total", 0) or 0),
            payment_method   = d.get("payment_method", "Cash"),
            status           = d.get("status", "Unpaid"),
            date             = d.get("date", ""),
            patient_name     = d.get("patient_name"),
            doctor_name      = d.get("doctor_name"),
            diagnosis        = d.get("diagnosis"),
        )

    def calculate_subtotal(self) -> float:
        """Pure method — sum of all charges before tax."""
        return (self.consultation_fee + self.treatment_cost +
                self.lab_fee + self.pharmacy_cost + self.ward_fee)

    def is_paid(self) -> bool:
        return self.status == "Paid"

    def to_dict(self) -> dict:
        return {
            "bill_id":          self.bill_id,
            "patient_id":       self.patient_id,
            "treatment_id":     self.treatment_id,
            "doctor_id":        self.doctor_id,
            "consultation_fee": self.consultation_fee,
            "treatment_cost":   self.treatment_cost,
            "lab_fee":          self.lab_fee,
            "pharmacy_cost":    self.pharmacy_cost,
            "ward_fee":         self.ward_fee,
            "tax":              self.tax,
            "total":            self.total,
            "payment_method":   self.payment_method,
            "status":           self.status,
            "date":             self.date,
        }
