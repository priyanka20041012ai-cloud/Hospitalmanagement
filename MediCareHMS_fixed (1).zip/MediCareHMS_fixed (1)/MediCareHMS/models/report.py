"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  models/report.py — Report domain model                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts:
  - Encapsulation: All report data (summary stats, monthly data) in one object.
  - Abstraction: build() class method hides how a report is assembled.
  - SRP: Represents a Report snapshot — no DB calls, no UI logic.

Design Pattern:
  - Builder Pattern (lightweight): ReportData.build(repos) constructs a
    complete report snapshot from multiple repositories in one call.
    The caller gets a clean object — not raw dicts from 5 different sources.
"""

from dataclasses import dataclass, field
from typing import List, Dict
from datetime import datetime


@dataclass
class ReportData:
    """
    Domain Model — represents a full HMS summary report snapshot.

    OOP → Encapsulation:
      All report metrics are in one object. Services and GUI
      receive this instead of querying 5 repos separately.

    Design Pattern → Builder (lightweight):
      ReportData.build(repos_dict) assembles the full picture
      from all repositories. One call, one clean object.
    """
    generated_at:       str
    total_patients:     int
    outpatients:        int
    inpatients:         int
    total_doctors:      int
    specializations:    int
    total_appointments: int
    today_appointments: int
    total_treatments:   int
    total_bills:        int
    paid_bills:         int
    unpaid_bills:       int
    total_revenue:      float
    paid_revenue:       float
    outstanding:        float
    collection_rate:    float
    monthly_revenue:    List[Dict]   = field(default_factory=list)
    appt_status_counts: Dict         = field(default_factory=dict)
    doctor_by_spec:     Dict         = field(default_factory=dict)
    monthly_patients:   List[Dict]   = field(default_factory=list)

    @staticmethod
    def build(pat_repo, doc_repo, appt_repo, treat_repo, bill_repo) -> "ReportData":
        """
        Builder method — assembles a complete report from all repositories.

        Design Pattern → Builder:
          Instead of the GUI calling 10+ different repo methods,
          it calls ReportData.build(...) and gets everything at once.

        OOP → Abstraction:
          The caller doesn't know HOW data is gathered.
          Just: report = ReportData.build(...)
        """
        patients  = pat_repo.get_all()
        docs      = doc_repo.get_all()
        bills     = bill_repo.get_all()
        out_c, in_c = pat_repo.count_by_type()
        total_rev = bill_repo.total_revenue()
        paid_rev  = bill_repo.paid_revenue()
        paid_bills   = sum(1 for b in bills if b["status"] == "Paid")
        unpaid_bills = sum(1 for b in bills if b["status"] == "Unpaid")

        return ReportData(
            generated_at       = datetime.now().strftime("%A, %d %B %Y  %H:%M:%S"),
            total_patients     = len(patients),
            outpatients        = out_c,
            inpatients         = in_c,
            total_doctors      = len(docs),
            specializations    = len(doc_repo.by_spec()),
            total_appointments = len(appt_repo.get_all()),
            today_appointments = len(appt_repo.get_today()),
            total_treatments   = len(treat_repo.get_all()),
            total_bills        = len(bills),
            paid_bills         = paid_bills,
            unpaid_bills       = unpaid_bills,
            total_revenue      = total_rev,
            paid_revenue       = paid_rev,
            outstanding        = round(total_rev - paid_rev, 2),
            collection_rate    = round((paid_rev / total_rev * 100) if total_rev else 0, 1),
            monthly_revenue    = bill_repo.monthly_revenue(),
            appt_status_counts = appt_repo.status_counts(),
            doctor_by_spec     = doc_repo.by_spec(),
            monthly_patients   = pat_repo.monthly_counts(),
        )

    def to_text(self) -> str:
        """
        Returns a formatted plain-text report string.
        Clean Code: presentation logic stays in the model's own method,
        not scattered across the GUI.
        """
        return f"""
 ╔══════════════════════════════════════════════════════════════════════════╗
 ║          ✚ MEDI CARE HOSPITAL (PVT) LTD — SUMMARY REPORT               ║
 ║   Generated : {self.generated_at}
 ╠══════════════════════════════════════════════════════════════════════════╣
   👤  PATIENTS        Total: {self.total_patients}  |  Outpatient: {self.outpatients}  |  Inpatient: {self.inpatients}
   🩺  DOCTORS         Total: {self.total_doctors}  |  Specializations: {self.specializations}
   📅  APPOINTMENTS    Total: {self.total_appointments}  |  Today: {self.today_appointments}
   💊  TREATMENTS      Total: {self.total_treatments}
   💰  BILLING         Bills: {self.total_bills}  |  Paid: {self.paid_bills}  |  Unpaid: {self.unpaid_bills}
       Total Revenue    : LKR {self.total_revenue:>15,.2f}
       Amount Collected : LKR {self.paid_revenue:>15,.2f}
       Outstanding      : LKR {self.outstanding:>15,.2f}
       Collection Rate  : {self.collection_rate:>14.1f}%
 ╚══════════════════════════════════════════════════════════════════════════╝
"""
