"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  models/patient.py — Patient domain model (data class)                     ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts Used:
  - Encapsulation: Patient data bundled into one object with validation.
  - Abstraction: Consumers use Patient.from_dict() — don't build raw dicts.
  - SRP: This class only represents a Patient entity. No DB logic here.

Clean Code:
  - Meaningful names, self-documenting attributes.
  - from_dict() factory method — clean object creation from DB rows.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Patient:
    """
    Domain Model — represents a single Patient entity.

    OOP → Encapsulation:
      All patient fields in one place. Other layers use this object,
      not raw dictionaries, ensuring type safety and clarity.

    OOP → Abstraction:
      from_dict() hides how raw DB rows become Patient objects.
    """
    patient_id: str
    name: str
    age: int
    gender: str
    phone: str
    address: str
    blood_group: str
    patient_type: str
    created_at: str

    @staticmethod
    def from_dict(d: dict) -> "Patient":
        """Factory method: creates Patient from a DB row dict."""
        return Patient(
            patient_id  = d.get("patient_id", ""),
            name        = d.get("name", ""),
            age         = d.get("age", 0),
            gender      = d.get("gender", ""),
            phone       = d.get("phone", ""),
            address     = d.get("address", ""),
            blood_group = d.get("blood_group", ""),
            patient_type= d.get("patient_type", ""),
            created_at  = d.get("created_at", ""),
        )

    def to_dict(self) -> dict:
        """Convert back to dict for DB insertion."""
        return {
            "patient_id":  self.patient_id,
            "name":        self.name,
            "age":         self.age,
            "gender":      self.gender,
            "phone":       self.phone,
            "address":     self.address,
            "blood_group": self.blood_group,
            "patient_type":self.patient_type,
            "created_at":  self.created_at,
        }
