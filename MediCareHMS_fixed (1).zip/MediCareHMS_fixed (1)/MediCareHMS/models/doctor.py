"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  models/doctor.py — Doctor domain model                                    ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP: Encapsulation + Abstraction (same pattern as Patient model).
"""

from dataclasses import dataclass


@dataclass
class Doctor:
    """
    Domain Model — represents a Doctor entity.

    OOP → Encapsulation: All doctor-related data is in one object.
    Clean Code → from_dict() factory method for clean instantiation.
    """
    doctor_id:      str
    name:           str
    age:            int
    gender:         str
    phone:          str
    specialization: str
    fee:            float
    reg_no:         str
    created_at:     str

    @staticmethod
    def from_dict(d: dict) -> "Doctor":
        return Doctor(
            doctor_id      = d.get("doctor_id", ""),
            name           = d.get("name", ""),
            age            = d.get("age", 0),
            gender         = d.get("gender", ""),
            phone          = d.get("phone", ""),
            specialization = d.get("specialization", ""),
            fee            = d.get("fee", 0.0),
            reg_no         = d.get("reg_no", ""),
            created_at     = d.get("created_at", ""),
        )

    def to_dict(self) -> dict:
        return {
            "doctor_id":      self.doctor_id,
            "name":           self.name,
            "age":            self.age,
            "gender":         self.gender,
            "phone":          self.phone,
            "specialization": self.specialization,
            "fee":            self.fee,
            "reg_no":         self.reg_no,
            "created_at":     self.created_at,
        }
