"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  repositories/repositories.py — IRepository (abstract) + all concrete      ║
║  Follows: Repository Pattern + SOLID Principles                             ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts Used:
  - Abstraction: IRepository is an Abstract Base Class (ABC).
    Every repository MUST implement add, get_all, find_by_id, update, delete.
  - Inheritance: PatientRepository, DoctorRepository, etc. inherit IRepository.
  - Polymorphism: Any repository can be used via IRepository type — same methods,
    different data. e.g., repo.get_all() works for patients AND doctors.
  - Encapsulation: Each repo hides its own SQL queries. External code just
    calls repo.add(data) without knowing any SQL.

SOLID Principles:
  - S (SRP): Each class handles ONE entity only (Patient, Doctor, Bill, etc.)
  - O (OCP): Add a new repository without modifying existing ones.
  - L (LSP): Any repo can replace IRepository — all honour the same contract.
  - I (ISP): IRepository has minimal interface — no bloated methods.
  - D (DIP): Repositories depend on DatabaseManager abstraction, not sqlite3.

Design Pattern:
  - Repository Pattern: Separates data access logic from business logic.
    Services/GUI never write SQL — they only call repository methods.
"""

import uuid
from abc import ABC, abstractmethod
from datetime import datetime


# ═══════════════════════════════════════════════════════════════════════
# ABSTRACT BASE — Abstraction + Interface Segregation + Dependency Inversion
# ═══════════════════════════════════════════════════════════════════════

class IRepository(ABC):
    """
    Abstract Repository Interface.

    OOP → Abstraction: Defines WHAT operations exist, not HOW.
    SOLID → ISP: Small, focused interface — only 5 core methods.
    SOLID → DIP: Consumers depend on this abstraction, not concrete classes.
    """

    @abstractmethod
    def add(self, d): pass

    @abstractmethod
    def get_all(self): pass

    @abstractmethod
    def find_by_id(self, id_str): pass

    @abstractmethod
    def update(self, id_str, d): pass

    @abstractmethod
    def delete(self, id_str): pass


# ═══════════════════════════════════════════════════════════════════════
# PATIENT REPOSITORY
# ═══════════════════════════════════════════════════════════════════════

class PatientRepository(IRepository):
    """
    Concrete Repository for Patient entity.

    OOP → Inheritance: Inherits IRepository, implements all abstract methods.
    OOP → Encapsulation: SQL queries are private implementation details.
    SOLID → SRP: Only handles patient-related DB operations.
    """

    def __init__(self, db):
        self.db = db  # Dependency Injection — db is passed in, not created here

    def _nid(self):
        return f"P-{str(uuid.uuid4())[:8].upper()}"

    def add(self, d):
        pid = self._nid()
        self.db.exe(
            "INSERT INTO patients VALUES (?,?,?,?,?,?,?,?,?)",
            (pid, d["name"], d["age"], d["gender"], d["phone"],
             d["address"], d["blood"], d["ptype"],
             datetime.now().strftime("%Y-%m-%d %H:%M")))
        return pid

    def get_all(self):
        return self.db.fetch("SELECT * FROM patients ORDER BY created_at DESC")

    def find_by_id(self, pid):
        return self.db.fetchone("SELECT * FROM patients WHERE patient_id=?", (pid,))

    def search(self, q):
        q = f"%{q}%"
        return self.db.fetch(
            "SELECT * FROM patients WHERE name LIKE ? OR patient_id LIKE ? OR phone LIKE ? OR blood_group LIKE ? ORDER BY created_at DESC",
            (q, q, q, q))

    def update(self, pid, d):
        self.db.exe(
            "UPDATE patients SET name=?,age=?,gender=?,phone=?,address=?,blood_group=?,patient_type=? WHERE patient_id=?",
            (d["name"], d["age"], d["gender"], d["phone"],
             d["address"], d["blood"], d["ptype"], pid))

    def delete(self, pid):

    # delete dependent records first
     self.db.exe("DELETE FROM bills WHERE patient_id=?", (pid,))
     self.db.exe("DELETE FROM treatments WHERE patient_id=?", (pid,))
     self.db.exe("DELETE FROM appointments WHERE patient_id=?", (pid,))

    # finally delete patient
     self.db.exe("DELETE FROM patients WHERE patient_id=?", (pid,))

    def count_by_type(self):
        out = self.db.fetchone("SELECT COUNT(*) AS c FROM patients WHERE patient_type='Outpatient'")["c"]
        inp = self.db.fetchone("SELECT COUNT(*) AS c FROM patients WHERE patient_type='Inpatient'")["c"]
        return out, inp

    def monthly_counts(self):
        return self.db.fetch(
            "SELECT strftime('%Y-%m',created_at) AS m, COUNT(*) AS c FROM patients GROUP BY m ORDER BY m DESC LIMIT 6")

    def get_for_doctor(self, doctor_id):
        return self.db.fetch("""
            SELECT DISTINCT p.* FROM patients p
            LEFT JOIN appointments a ON p.patient_id=a.patient_id AND a.doctor_id=?
            LEFT JOIN treatments t ON p.patient_id=t.patient_id AND t.doctor_id=?
            WHERE a.doctor_id=? OR t.doctor_id=?
            ORDER BY p.created_at DESC
        """, (doctor_id, doctor_id, doctor_id, doctor_id))


# ═══════════════════════════════════════════════════════════════════════
# DOCTOR REPOSITORY
# ═══════════════════════════════════════════════════════════════════════

class DoctorRepository(IRepository):
    """
    Concrete Repository for Doctor entity.
    OOP → SRP: Only handles doctor DB operations. Nothing else.
    """

    def __init__(self, db):
        self.db = db

    def _nid(self):
        return f"D-{str(uuid.uuid4())[:8].upper()}"

    def add(self, d):
        did = self._nid()
        self.db.exe(
            "INSERT INTO doctors VALUES (?,?,?,?,?,?,?,?,?)",
            (did, d["name"], d["age"], d["gender"], d["phone"],
             d["spec"], d["fee"], d["regno"],
             datetime.now().strftime("%Y-%m-%d %H:%M")))
        return did

    def get_all(self):
        return self.db.fetch("SELECT * FROM doctors ORDER BY created_at DESC")

    def find_by_id(self, did):
        return self.db.fetchone("SELECT * FROM doctors WHERE doctor_id=?", (did,))

    def update(self, did, d):
        self.db.exe(
            "UPDATE doctors SET name=?,age=?,gender=?,phone=?,specialization=?,fee=?,reg_no=? WHERE doctor_id=?",
            (d["name"], d["age"], d["gender"], d["phone"],
             d["spec"], d["fee"], d["regno"], did))

    def delete(self, did):
        self.db.exe("DELETE FROM doctors WHERE doctor_id=?", (did,))

    def by_spec(self):
        rows = self.db.fetch("SELECT specialization,COUNT(*) AS c FROM doctors GROUP BY specialization")
        return {r["specialization"]: r["c"] for r in rows}

    def get_all_with_users(self):
        return self.db.fetch("""
            SELECT d.*, u.username, u.full_name AS user_full_name,
                   u.role AS user_role, u.id AS user_id
            FROM doctors d
            LEFT JOIN users u ON u.doctor_id = d.doctor_id
            ORDER BY d.created_at DESC
        """)


# ═══════════════════════════════════════════════════════════════════════
# APPOINTMENT REPOSITORY
# ═══════════════════════════════════════════════════════════════════════

class AppointmentRepository(IRepository):
    """
    Concrete Repository for Appointment entity.
    OOP Polymorphism: get_all() here returns appointment rows — same method
    name as PatientRepository.get_all() but different SQL and data shape.
    """

    def __init__(self, db):
        self.db = db

    def _nid(self):
        return f"APT-{str(uuid.uuid4())[:6].upper()}"

    def add(self, d):
        aid = self._nid()
        self.db.exe(
            "INSERT INTO appointments VALUES (?,?,?,?,?,?,?,?,?)",
            (aid, d["patient_id"], d["doctor_id"], d["date"], d["time"],
             d["reason"], d["atype"], "Scheduled",
             datetime.now().strftime("%Y-%m-%d %H:%M")))
        return aid

    def get_all(self):
        return self.db.fetch("""
            SELECT a.*,p.name AS patient_name,p.phone AS patient_phone,
                   d.name AS doctor_name,d.specialization
            FROM appointments a
            JOIN patients p ON a.patient_id=p.patient_id
            JOIN doctors d ON a.doctor_id=d.doctor_id
            ORDER BY a.date DESC, a.time
        """)

    def get_today(self):
        today = datetime.now().strftime("%Y-%m-%d")
        return self.db.fetch("""
            SELECT a.*,p.name AS patient_name,p.phone AS patient_phone,
                   d.name AS doctor_name,d.specialization
            FROM appointments a
            JOIN patients p ON a.patient_id=p.patient_id
            JOIN doctors d ON a.doctor_id=d.doctor_id
            WHERE a.date=? ORDER BY a.time
        """, (today,))

    def get_for_doctor(self, doctor_id):
        return self.db.fetch("""
            SELECT a.*,p.name AS patient_name,p.phone AS patient_phone,
                   d.name AS doctor_name
            FROM appointments a
            JOIN patients p ON a.patient_id=p.patient_id
            JOIN doctors d ON a.doctor_id=d.doctor_id
            WHERE a.doctor_id=? ORDER BY a.date DESC, a.time
        """, (doctor_id,))

    def find_by_id(self, aid):
        return self.db.fetchone("""
            SELECT a.*,p.name AS patient_name,p.phone AS patient_phone,
                   d.name AS doctor_name
            FROM appointments a
            JOIN patients p ON a.patient_id=p.patient_id
            JOIN doctors d ON a.doctor_id=d.doctor_id
            WHERE a.appointment_id=?
        """, (aid,))

    def update(self, aid, d):
        self.db.exe(
            "UPDATE appointments SET date=?,time=?,reason=?,appt_type=?,status=? WHERE appointment_id=?",
            (d["date"], d["time"], d["reason"], d["atype"], d["status"], aid))

    def update_status(self, aid, status):
        self.db.exe("UPDATE appointments SET status=? WHERE appointment_id=?", (status, aid))

    def delete(self, aid):
        self.db.exe("DELETE FROM appointments WHERE appointment_id=?", (aid,))

    def status_counts(self):
        rows = self.db.fetch("SELECT status,COUNT(*) AS c FROM appointments GROUP BY status")
        return {r["status"]: r["c"] for r in rows}


# ═══════════════════════════════════════════════════════════════════════
# TREATMENT REPOSITORY
# ═══════════════════════════════════════════════════════════════════════

class TreatmentRepository(IRepository):
    """Concrete Repository for Treatment entity. SRP: treatments only."""

    def __init__(self, db):
        self.db = db

    def _nid(self):
        return f"TRT-{str(uuid.uuid4())[:6].upper()}"

    def add(self, d):
        tid = self._nid()
        self.db.exe(
            "INSERT INTO treatments VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (tid, d["patient_id"], d["doctor_id"], d["diag"], d["med"],
             d["lab"], d["pharma"], d["ward"], d["notes"], d["cost"],
             datetime.now().strftime("%Y-%m-%d %H:%M")))
        return tid

    def get_all(self):
        return self.db.fetch("""
            SELECT t.*,p.name AS patient_name,d.name AS doctor_name
            FROM treatments t
            JOIN patients p ON t.patient_id=p.patient_id
            JOIN doctors d ON t.doctor_id=d.doctor_id
            ORDER BY t.date DESC
        """)

    def get_for_doctor(self, doctor_id):
        return self.db.fetch("""
            SELECT t.*,p.name AS patient_name,d.name AS doctor_name
            FROM treatments t
            JOIN patients p ON t.patient_id=p.patient_id
            JOIN doctors d ON t.doctor_id=d.doctor_id
            WHERE t.doctor_id=? ORDER BY t.date DESC
        """, (doctor_id,))

    def find_by_id(self, tid):
        return self.db.fetchone("SELECT * FROM treatments WHERE treatment_id=?", (tid,))

    def update(self, tid, d):
        self.db.exe(
            "UPDATE treatments SET diagnosis=?,medication=?,lab_tests=?,pharmacy_items=?,ward=?,notes=?,treatment_cost=? WHERE treatment_id=?",
            (d["diag"], d["med"], d["lab"], d["pharma"],
             d["ward"], d["notes"], d["cost"], tid))

    def delete(self, tid):
        self.db.exe("DELETE FROM bills WHERE treatment_id=?", (tid,))
        self.db.exe("DELETE FROM treatments WHERE treatment_id=?", (tid,))


# ═══════════════════════════════════════════════════════════════════════
# BILL REPOSITORY
# ═══════════════════════════════════════════════════════════════════════

class BillRepository(IRepository):
    """Concrete Repository for Bill entity. SRP: billing only."""

    def __init__(self, db):
        self.db = db

    def _nid(self):
        return f"BILL-{str(uuid.uuid4())[:6].upper()}"

    def add(self, d):
        bid = self._nid()
        sub = (d["consultation"] + d["treatment_cost"] +
               d["lab"] + d["pharma"] + d["ward"])
        tax   = round(sub * 0.05, 2)
        total = round(sub + tax, 2)
        self.db.exe(
            "INSERT INTO bills VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (bid, d["patient_id"], d["treatment_id"], d["doctor_id"],
             d["consultation"], d["treatment_cost"], d["lab"], d["pharma"],
             d["ward"], tax, total, "Cash", "Unpaid",
             datetime.now().strftime("%Y-%m-%d %H:%M")))
        return bid

    def get_all(self):
        return self.db.fetch("""
            SELECT b.*,p.name AS patient_name, p.patient_id,
                   d.name AS doctor_name, t.diagnosis
            FROM bills b
            JOIN patients p ON b.patient_id=p.patient_id
            JOIN doctors d ON b.doctor_id=d.doctor_id
            JOIN treatments t ON b.treatment_id=t.treatment_id
            ORDER BY b.date DESC
        """)

    def find_by_id(self, bid):
        return self.db.fetchone("""
            SELECT b.*,p.name AS patient_name,p.blood_group,
                   d.name AS doctor_name,d.specialization,d.reg_no,
                   t.diagnosis,t.medication,t.lab_tests,
                   t.pharmacy_items,t.ward,t.treatment_id
            FROM bills b
            JOIN patients p ON b.patient_id=p.patient_id
            JOIN doctors d ON b.doctor_id=d.doctor_id
            JOIN treatments t ON b.treatment_id=t.treatment_id
            WHERE b.bill_id=?
        """, (bid,))

    def mark_paid(self, bid, method):
        self.db.exe(
            "UPDATE bills SET status='Paid',payment_method=? WHERE bill_id=?",
            (method, bid))

    def total_revenue(self):
        r = self.db.fetchone("SELECT SUM(total) AS s FROM bills")
        return r["s"] or 0.0

    def paid_revenue(self):
        r = self.db.fetchone("SELECT SUM(total) AS s FROM bills WHERE status='Paid'")
        return r["s"] or 0.0

    def monthly_revenue(self):
        return self.db.fetch(
            "SELECT strftime('%Y-%m',date) AS m,SUM(total) AS s FROM bills WHERE status='Paid' GROUP BY m ORDER BY m DESC LIMIT 6")

    def update(self, bid, d):
        self.db.exe(
            "UPDATE bills SET payment_method=?,status=? WHERE bill_id=?",
            (d["method"], d["status"], bid))

    def delete(self, bid):
        self.db.exe("DELETE FROM bills WHERE bill_id=?", (bid,))
