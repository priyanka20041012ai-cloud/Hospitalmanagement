import unittest
from services.patient_service import PatientService

class TestPatientService(unittest.TestCase):

    def setUp(self):
        # Initialize service without database (unit testing)
        self.patient_service = PatientService(None)

    def register_patient(self, name, age, gender, phone,
                     address, blood_group, patient_type):
   
    # Name validation
     if not name or name.strip() == "":
        raise ValueError("Patient name cannot be empty.")

    # Age validation
     if age < 0:
        raise ValueError("Age cannot be negative.")

    # (Optional but good practice)
     if not phone or len(phone) < 10:
        raise ValueError("Invalid phone number.")

    # Continue normal logic
     return {
        "name": name,
        "age": age,
        "gender": gender,
        "phone": phone,
        "address": address,
        "blood_group": blood_group,
        "patient_type": patient_type
    }
# import unittest
# from services.patient_service import PatientService
# from repositories.repositories import PatientRepository
# from core.database import DatabaseManager

# class TestPatientIntegration(unittest.TestCase):

#     def setUp(self):
#         self.db = DatabaseManager()
#         self.repo = PatientRepository(self.db)
#         self.service = PatientService(self.repo)

#     def test_register_patient(self):
#         patient_id = self.service.register_patient(
#             "John Doe", 25, "Male",
#             "0771234567", "Colombo", "O+", "Outpatient"
#         )
#         self.assertIsNotNone(patient_id)