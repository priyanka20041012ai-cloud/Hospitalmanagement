import unittest
from services.billing_service import BillingService

class BillingService:

    def __init__(self, bill_repo=None, treat_repo=None, doc_repo=None):
        self._bill_repo = bill_repo
        self._treat_repo = treat_repo
        self._doc_repo = doc_repo

    # ❌ WRONG METHOD (for showing failure)
    def calculate_total(self, consultation, treatment_cost, lab, pharma, ward):
        subtotal = consultation + treatment_cost + lab + pharma + ward
        
        # ❌ Missing tax calculation
        return {
            "subtotal": subtotal,
            "total": subtotal   # returns 1500 instead of 1575
        }
  
    