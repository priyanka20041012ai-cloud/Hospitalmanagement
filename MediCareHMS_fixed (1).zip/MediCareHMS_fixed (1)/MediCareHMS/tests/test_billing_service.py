import unittest
from services.billing_service import BillingService

class TestBillingService(unittest.TestCase):

    def setUp(self):
        self.billing = BillingService(None, None, None)

    def calculate_total(self, consultation: float, treatment_cost: float,
                     lab: float, pharma: float, ward: float) -> dict:
    
    #  Validation (Fix)
     values = [consultation, treatment_cost, lab, pharma, ward]
     if any(v < 0 for v in values):
      raise ValueError("Billing values cannot be negative.")

     subtotal = consultation + treatment_cost + lab + pharma + ward
     tax      = round(subtotal * self.TAX_RATE, 2)
     total    = round(subtotal + tax, 2)

     return {
        "subtotal": subtotal,
        "tax":      tax,
        "total":    total,
    }