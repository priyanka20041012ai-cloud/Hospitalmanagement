"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  gui/app.py — MediCareHMS main application class                            ║
║  Handles: Login, Sidebar, Navigation, Theme, All Pages                      ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts Used:
  - Inheritance: MediCareHMS extends tk.Tk — inherits the entire Tkinter
    window management system. We ADD hospital-specific behaviour on top.
  - Encapsulation: All app state (current_user, theme, repos) is inside
    this class. External code never touches these directly.
  - Composition: MediCareHMS HAS-A DatabaseManager, HAS-A PatientRepository,
    etc. This is Composition over Inheritance for data access.
  - Abstraction: _show(key) method hides HOW pages are loaded.
    Callers just say self._show("dashboard").

Design Patterns:
  - MVC (Model-View-Controller): Models = repositories/data, View = pages.py,
    Controller = app.py (handles navigation, events, and coordinates them).
  - Facade: _stat_card(), _tree(), _crud_toolbar() are reusable UI facades —
    pages call these instead of building raw Tkinter widgets every time.

SOLID:
  - SRP: app.py handles navigation and UI structure.
    Data access is in repositories. Pages are in pages.py. Dialogs in dialogs.py.
  - OCP: Adding a new page = add one method + one nav entry. Nothing else changes.
  - DIP: MediCareHMS depends on IRepository (abstraction), not sqlite3 directly.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import hashlib, uuid

from core.constants import (THEMES, BRAND, RED, GREEN, AMBER, PURPLE,
                              TEAL, PINK, WHITE_FIXED,
                              F_HUGE, F_HEAD, F_SUB, F_BODY, F_SMALL,
                              F_MONO, F_NAV, F_BTN)
from core.database import DatabaseManager
from repositories.repositories import (PatientRepository, DoctorRepository,
                                         AppointmentRepository, TreatmentRepository,
                                         BillRepository)
from utils.helpers import RoundBtn, export_bill_pdf
from gui.dialogs import (WelcomeScreen, LoginScreen, EditDialog,
                          SMSDialog, PharmacySelectorDialog)

# try:
#     import matplotlib
#     matplotlib.use("TkAgg")
#     import matplotlib.pyplot as plt
#     from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
#     HAS_MPLOT = True
# except ImportError:
#     HAS_MPLOT = False


class MediCareHMS(tk.Tk):
    """
    Main Application Window.

    OOP → Inheritance: extends tk.Tk — IS-A Tkinter window.
    OOP → Composition: HAS-A db, pat_repo, doc_repo, etc.
    Design Pattern → MVC Controller: coordinates models (repos) + views (pages).
    Design Pattern → Facade: _tree(), _stat_card() hide Tkinter complexity.
    """

    def __init__(self):
        super().__init__()
        self.withdraw()
        self.title("Medi Care Hospital (PVT) Ltd — HMS v7.0")
        self.geometry("1400x820")
        self.minsize(1150, 680)
        self.resizable(True, True)

        # Composition: app HAS these dependencies
        self.db         = DatabaseManager()
        self.pat_repo   = PatientRepository(self.db)
        self.doc_repo   = DoctorRepository(self.db)
        self.appt_repo  = AppointmentRepository(self.db)
        self.treat_repo = TreatmentRepository(self.db)
        self.bill_repo  = BillRepository(self.db)

        self.current_user  = None
        self._nav_items    = []
        self._theme_name   = "light"
        self.T             = THEMES["light"].copy()
        self._current_page = "dashboard"

        self._seed_demo()
        self._configure_styles()
        WelcomeScreen(self, self._show_login)
        self.mainloop()

    # ─── Demo Data Seeding ────────────────────────────────────────────────────
    def _seed_demo(self):
        if self.pat_repo.get_all(): return
        docs = [
            {"name": "Dr. Nimal Perera",  "age": 50, "gender": "Male",   "phone": "0112345678", "spec": "Cardiology",       "fee": 3500, "regno": "SLMC-1234"},
            {"name": "Dr. Sandya Silva",   "age": 42, "gender": "Female", "phone": "0119876543", "spec": "Neurology",        "fee": 4000, "regno": "SLMC-2345"},
            {"name": "Dr. Ruwan Fernando", "age": 55, "gender": "Male",   "phone": "0117654321", "spec": "Orthopedics",      "fee": 3000, "regno": "SLMC-3456"},
            {"name": "Dr. Priya Raj",      "age": 36, "gender": "Female", "phone": "0113456789", "spec": "Pediatrics",       "fee": 2500, "regno": "SLMC-4567"},
            {"name": "Dr. Asanka W.",      "age": 48, "gender": "Male",   "phone": "0115678901", "spec": "General Medicine", "fee": 2000, "regno": "SLMC-5678"},
        ]
        dids = [self.doc_repo.add(d) for d in docs]
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        doc_user_id = str(uuid.uuid4())[:8].upper()
        self.db.exe("INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (doc_user_id, "doctor", self.db._hash("doc123"),
             "Dr. Nimal Perera", "Doctor", "Cardiology", "0112345678",
             "nimal@medicare.lk", now, "light", dids[0]))
        for i, did in enumerate(dids[1:], 1):
            d = docs[i]
            uname = d["name"].lower().replace("dr. ", "").replace("dr.", "").replace(" ", "_")[:12]
            uid2 = str(uuid.uuid4())[:8].upper()
            try:
                self.db.exe("INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (uid2, uname, self.db._hash("doc123"),
                     d["name"], "Doctor", d["spec"], d["phone"], None, now, "light", did))
            except Exception:
                pass

        patients = [
            {"name": "Kamal Jayasinghe", "age": 34, "gender": "Male",   "phone": "0771234567", "address": "Galle",      "blood": "O+",  "ptype": "Outpatient"},
            {"name": "Nadeeka Wickrama", "age": 28, "gender": "Female", "phone": "0779876543", "address": "Colombo 06", "blood": "A+",  "ptype": "Inpatient"},
            {"name": "Saman Perera",     "age": 52, "gender": "Male",   "phone": "0776543210", "address": "Kandy",      "blood": "B+",  "ptype": "Outpatient"},
            {"name": "Dilani Fernando",  "age": 41, "gender": "Female", "phone": "0772345678", "address": "Colombo 03", "blood": "AB+", "ptype": "Outpatient"},
        ]
        pids  = [self.pat_repo.add(p) for p in patients]
        today = datetime.now().strftime("%Y-%m-%d")
        self.appt_repo.add({"patient_id": pids[0], "doctor_id": dids[0], "date": today, "time": "10:00 AM", "reason": "Chest pain",      "atype": "Outpatient Consultation"})
        self.appt_repo.add({"patient_id": pids[1], "doctor_id": dids[0], "date": today, "time": "11:30 AM", "reason": "Follow up check", "atype": "Follow-up"})
        self.appt_repo.add({"patient_id": pids[2], "doctor_id": dids[1], "date": today, "time": "02:00 PM", "reason": "Headache",        "atype": "Outpatient Consultation"})
        self.appt_repo.add({"patient_id": pids[3], "doctor_id": dids[2], "date": today, "time": "03:30 PM", "reason": "Knee pain",       "atype": "Outpatient Consultation"})

        tid  = self.treat_repo.add({"patient_id": pids[0], "doctor_id": dids[0], "diag": "Hypertension Stage-1", "med": "Amlodipine 5mg OD",  "lab": "ECG, Full Blood Count", "pharma": "Vitamin C, Omega-3", "ward": "",       "notes": "Monitor BP daily",   "cost": 1500.0})
        tid2 = self.treat_repo.add({"patient_id": pids[1], "doctor_id": dids[0], "diag": "Migraine",             "med": "Sumatriptan 50mg",   "lab": "MRI Brain",             "pharma": "Paracetamol 500mg",  "ward": "Ward 3B","notes": "Rest recommended",   "cost": 2200.0})
        tid3 = self.treat_repo.add({"patient_id": pids[2], "doctor_id": dids[1], "diag": "Tension Headache",     "med": "Ibuprofen 400mg BD", "lab": "CT Scan",               "pharma": "Cetirizine 10mg",    "ward": "",       "notes": "Follow up in 2 wks", "cost": 1800.0})

        doc0 = self.doc_repo.find_by_id(dids[0])
        self.bill_repo.add({"patient_id": pids[0], "treatment_id": tid,  "doctor_id": dids[0], "consultation": doc0["fee"], "treatment_cost": 1500.0, "lab": 750.0,  "pharma": 500.0, "ward": 0.0})
        self.bill_repo.add({"patient_id": pids[1], "treatment_id": tid2, "doctor_id": dids[0], "consultation": doc0["fee"], "treatment_cost": 2200.0, "lab": 1200.0, "pharma": 180.0, "ward": 800.0})

    # ─── Styles ───────────────────────────────────────────────────────────────
    def _configure_styles(self):
        T = self.T
        s = ttk.Style(self); s.theme_use("clam")
        s.configure("Treeview", background=T["CARD"], foreground=T["TEXT"],
                    fieldbackground=T["CARD"], rowheight=30, font=F_BODY, borderwidth=0)
        s.configure("Treeview.Heading", background=T["BG"], foreground=T["TEXT2"],
                    font=F_SUB, relief="flat", padding=(8, 6))
        s.map("Treeview", background=[("selected", BRAND)], foreground=[("selected", WHITE_FIXED)])
        s.configure("TCombobox", fieldbackground=T["INPUT_BG"], background=T["INPUT_BG"],
                    foreground=T["TEXT"], font=F_BODY, relief="flat", arrowcolor=T["TEXT2"], padding=6)
        s.map("TCombobox", fieldbackground=[("readonly", T["INPUT_BG"])])
        s.configure("TNotebook", background=T["BG"], borderwidth=0)
        s.configure("TNotebook.Tab", background=T["CARD"], foreground=T["TEXT2"], font=F_SUB, padding=[14, 8])
        s.map("TNotebook.Tab", background=[("selected", BRAND)], foreground=[("selected", WHITE_FIXED)])

    def _toggle_theme(self):
        self._theme_name = "dark" if self._theme_name == "light" else "light"
        self.T = THEMES[self._theme_name].copy()
        self.db.exe("UPDATE users SET theme=? WHERE id=?",
                    (self._theme_name, self.current_user["id"]))
        self._configure_styles()
        self.configure(bg=self.T["BG"])
        self._build_main_ui()
        self._show(self._current_page)

    def _show_login(self):
        LoginScreen(self, self.db, self._on_login)

    def _on_login(self, user):
        self.current_user = user
        fresh = self.db.fetchone("SELECT * FROM users WHERE id=?", (user["id"],))
        if fresh: self.current_user = dict(fresh)
        self._theme_name = self.current_user.get("theme", "light") or "light"
        self.T = THEMES[self._theme_name].copy()
        self.configure(bg=self.T["BG"])
        self.deiconify()
        self._configure_styles()
        self._build_main_ui()
        self._current_page = "dashboard"
        self._show("dashboard")

    def _get_doctor_id_for_user(self):
        uid = self.current_user.get("id")
        if not uid: return None
        row = self.db.fetchone("SELECT doctor_id FROM users WHERE id=?", (uid,))
        if row and row.get("doctor_id"): return row["doctor_id"]
        return None

    def _is_admin(self):  return self.current_user.get("role") == "Admin"
    def _is_doctor(self): return self.current_user.get("role") == "Doctor"

    def _build_main_ui(self):
        for w in self.winfo_children(): w.destroy()
        T = self.T
        is_admin  = self._is_admin()
        is_doctor = self._is_doctor()

        self.sidebar = tk.Frame(self, bg=T["SIDEBAR_BG"], width=240)
        self.sidebar.pack(fill="y", side="left")
        self.sidebar.pack_propagate(False)

        lc = tk.Canvas(self.sidebar, width=240, height=82,
                        bg=T["SIDEBAR_BG"], highlightthickness=0); lc.pack()
        lc.create_oval(14, 16, 54, 56, fill=BRAND, outline="")
        lc.create_text(34, 36, text="✚", font=("Helvetica", 16, "bold"), fill=WHITE_FIXED)
        lc.create_text(135, 28, text="MEDI CARE", font=("Helvetica", 11, "bold"),
                        fill=WHITE_FIXED, anchor="w")
        lc.create_text(135, 46, text="HOSPITAL (PVT) LTD",
                        font=("Helvetica", 8), fill="#94A3B8", anchor="w")

        tk.Frame(self.sidebar, bg="#2D3748", height=1).pack(fill="x", padx=16)
        ub = tk.Frame(self.sidebar, bg=T["SIDEBAR_BG"], padx=16, pady=8); ub.pack(fill="x")
        role_icon = "👑" if is_admin else ("🩺" if is_doctor else "👤")
        tk.Label(ub, text=f"{role_icon} {self.current_user['full_name']}",
                 font=F_SMALL, fg="#94A3B8", bg=T["SIDEBAR_BG"]).pack(anchor="w")
        tk.Label(ub, text=f"  {self.current_user['role']}",
                 font=("Helvetica", 8), fg="#4B5563", bg=T["SIDEBAR_BG"]).pack(anchor="w")

        tk.Frame(self.sidebar, bg="#2D3748", height=1).pack(fill="x", padx=16)
        tk.Label(self.sidebar, text="NAVIGATION", font=("Helvetica", 8, "bold"),
                 fg="#4B5563", bg=T["SIDEBAR_BG"]).pack(anchor="w", padx=20, pady=(10, 4))

        if is_doctor:
            nav = [("dashboard",       "🏠", "Dashboard"),
                   ("my_patients",     "👥", "My Patients"),
                   ("my_appointments", "📅", "My Appointments"),
                   ("my_treatments",   "💊", "My Treatments"),
                   ("profile",         "⚙",  "My Profile")]
        else:
            nav = [("dashboard",  "🏠", "Dashboard"),
                   ("patients",   "👤", "Patients"),
                   ("doctors",    "🩺", "Doctors"),
                   ("appts",      "📅", "Appointments"),
                   ("treatments", "💊", "Treatments"),
                   ("billing",    "💰", "Billing"),
                   ("reports",    "📊", "Reports"),
                   ("profile",    "⚙",  "Profile & Settings")]

        self._nav_items = []
        for key, icon, label in nav:
            self._make_nav(key, icon, label)

        tk.Frame(self.sidebar, bg="#2D3748", height=1).pack(fill="x", padx=16, pady=6)
        theme_lbl = "☀ Light Mode" if self._theme_name == "dark" else "🌙 Dark Mode"
        RoundBtn(self.sidebar, theme_lbl, self._toggle_theme,
                 bg="#374151", fg=WHITE_FIXED).pack(pady=4, padx=16, fill="x")
        self._clock_lbl = tk.Label(self.sidebar, text="", font=("Helvetica", 8),
                                    fg="#4B5563", bg=T["SIDEBAR_BG"])
        self._clock_lbl.pack()
        self._tick()
        RoundBtn(self.sidebar, "⏻  Logout", self._logout,
                 bg="#DC2626", fg=WHITE_FIXED).pack(pady=6, padx=16, fill="x")

        right = tk.Frame(self, bg=T["BG"]); right.pack(fill="both", expand=True)
        self.topbar = tk.Frame(right, bg=T["TOPBAR"], height=60)
        self.topbar.pack(fill="x"); self.topbar.pack_propagate(False)
        tk.Frame(right, bg=T["BORDER"], height=1).pack(fill="x")
        self._tb_title = tk.Label(self.topbar, text="", font=F_HEAD,
                                   fg=T["TEXT"], bg=T["TOPBAR"])
        self._tb_title.pack(side="left", padx=24, pady=18)
        self._tb_sub = tk.Label(self.topbar, text="", font=F_SMALL,
                                 fg=T["TEXT2"], bg=T["TOPBAR"])
        self._tb_sub.pack(side="right", padx=24)
        self.content = tk.Frame(right, bg=T["BG"])
        self.content.pack(fill="both", expand=True)

    def _make_nav(self, key, icon, label):
        T = self.T
        f = tk.Frame(self.sidebar, bg=T["SIDEBAR_BG"], cursor="hand2")
        f.pack(fill="x", padx=8, pady=1)
        ind   = tk.Frame(f, bg=T["SIDEBAR_BG"], width=3); ind.pack(side="left", fill="y")
        inner = tk.Frame(f, bg=T["SIDEBAR_BG"], pady=9, padx=10)
        inner.pack(fill="x", expand=True, side="left")
        il = tk.Label(inner, text=icon, font=("Helvetica", 13), fg="#94A3B8", bg=T["SIDEBAR_BG"])
        il.pack(side="left")
        tl = tk.Label(inner, text=f" {label}", font=F_NAV, fg="#94A3B8", bg=T["SIDEBAR_BG"])
        tl.pack(side="left")
        for w in (f, inner, il, tl):
            w.bind("<Button-1>", lambda e, k=key: self._show(k))
        self._nav_items.append({"key": key, "f": f, "inner": inner,
                                 "il": il, "tl": tl, "ind": ind})

    def _activate_nav(self, key):
        T = self.T
        for item in self._nav_items:
            on = item["key"] == key
            bg = T["SIDEBAR_ACT"] if on else T["SIDEBAR_BG"]
            fg = WHITE_FIXED if on else "#94A3B8"
            for w in (item["f"], item["inner"], item["il"], item["tl"]):
                w.config(bg=bg)
            item["il"].config(fg=BRAND if on else "#94A3B8")
            item["tl"].config(fg=fg)
            item["ind"].config(bg=BRAND if on else T["SIDEBAR_BG"])

    def _tick(self):
        try:
            if self._clock_lbl.winfo_exists():
                self._clock_lbl.config(text=datetime.now().strftime("%a %d %b  %H:%M:%S"))
                self.after(1000, self._tick)
        except Exception:
            pass

    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.current_user = None
            for w in self.winfo_children(): w.destroy()
            self.withdraw()
            WelcomeScreen(self, self._show_login)

    def _show(self, key):
        self._current_page = key
        self._activate_nav(key)
        self._clear()
        page_fn = getattr(self, f"_page_{key}", None)
        if page_fn:
            page_fn()
        else:
            tk.Label(self.content, text=f"Page '{key}' not found.",
                     font=F_HEAD, fg=RED, bg=self.T["BG"]).pack(pady=40)

    def _clear(self):
        for w in self.content.winfo_children(): w.destroy()

    def _topbar(self, title, sub=""):
        self._tb_title.config(text=title, fg=self.T["TEXT"], bg=self.T["TOPBAR"])
        self._tb_sub.config(text=sub, fg=self.T["TEXT2"], bg=self.T["TOPBAR"])
        self.topbar.config(bg=self.T["TOPBAR"])

    # ─── Reusable UI Facades ──────────────────────────────────────────────────

    def _scrollable(self):
        T = self.T
        c = tk.Canvas(self.content, bg=T["BG"], highlightthickness=0)
        sb = ttk.Scrollbar(self.content, orient="vertical", command=c.yview)
        c.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y"); c.pack(fill="both", expand=True)
        page = tk.Frame(c, bg=T["BG"])
        c.create_window((0, 0), window=page, anchor="nw")
        page.bind("<Configure>", lambda e: c.configure(scrollregion=c.bbox("all")))
        c.bind("<MouseWheel>", lambda e: c.yview_scroll(-1*(e.delta//120), "units"))
        return page

    def _form_card(self, parent, title, color):
        T = self.T
        outer = tk.Frame(parent, bg=T["CARD"]); outer.pack(fill="x", padx=24, pady=10)
        tk.Frame(outer, bg=color, height=3).pack(fill="x")
        hdr = tk.Frame(outer, bg=T["CARD"], padx=16, pady=8); hdr.pack(fill="x")
        tk.Label(hdr, text=title, font=F_SUB, fg=color, bg=T["CARD"]).pack(anchor="w")
        tk.Frame(outer, bg=T["BORDER"], height=1).pack(fill="x")
        body = tk.Frame(outer, bg=T["CARD"], padx=18, pady=12); body.pack(fill="x")
        return body

    def _lbl_entry(self, parent, label, row, col, var, color, w=22):
        T = self.T
        tk.Label(parent, text=label, font=F_SMALL, fg=T["TEXT2"], bg=T["CARD"]).grid(
            row=row*2, column=col, padx=(0, 8), pady=(6, 2), sticky="w")
        e = tk.Entry(parent, textvariable=var, font=F_BODY, bg=T["INPUT_BG"], fg=T["TEXT"],
                     bd=0, highlightthickness=1, highlightbackground=T["BORDER"],
                     highlightcolor=color, insertbackground=color, width=w)
        e.grid(row=row*2+1, column=col, padx=(0, 14), pady=(0, 4), sticky="ew")
        parent.columnconfigure(col, weight=1); return e

    def _lbl_combo(self, parent, label, row, col, var, values, color, w=18):
        T = self.T
        tk.Label(parent, text=label, font=F_SMALL, fg=T["TEXT2"], bg=T["CARD"]).grid(
            row=row*2, column=col, padx=(0, 8), pady=(6, 2), sticky="w")
        cb = ttk.Combobox(parent, textvariable=var, values=values,
                           font=F_BODY, width=w, state="readonly")
        cb.grid(row=row*2+1, column=col, padx=(0, 14), pady=(0, 4), sticky="ew")
        parent.columnconfigure(col, weight=1); return cb

    def _stat_card(self, parent, label, value, color, light, icon, col):
        T = self.T
        card = tk.Frame(parent, bg=T["CARD"]); card.grid(row=0, column=col, padx=6, pady=4, sticky="ew")
        parent.columnconfigure(col, weight=1)
        tk.Frame(card, bg=color, height=4).pack(fill="x")
        body = tk.Frame(card, bg=T["CARD"], padx=16, pady=12); body.pack(fill="x")
        tk.Label(body, text=icon, font=("Helvetica", 18), fg=color,
                 bg=T["CARD2"], width=3, pady=4).pack(side="right")
        tk.Label(body, text=str(value), font=F_HUGE, fg=T["TEXT"], bg=T["CARD"]).pack(anchor="w")
        tk.Label(body, text=label, font=F_SMALL, fg=T["TEXT2"], bg=T["CARD"]).pack(anchor="w")

    def _tree(self, parent, columns, height=10):
        T = self.T
        wrap = tk.Frame(parent, bg=T["CARD"])
        wrap.pack(fill="both", expand=True, padx=24, pady=(4, 10))
        tree = ttk.Treeview(wrap, columns=columns, show="headings", height=height)
        vsb = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        hsb = ttk.Scrollbar(wrap, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        for col in columns:
            tree.heading(col, text=col)
            w = (70 if col in ("Age", "Status", "Gender", "Time") else
                 100 if col in ("ID", "Phone", "Date", "Blood", "Type") else 130)
            tree.column(col, width=w, minwidth=50, anchor="center")
        tree.tag_configure("even", background=T["TREE_ROW"])
        tree.tag_configure("odd",  background=T["TREE_ROW2"])
        tree.tag_configure("paid",      foreground=GREEN)
        tree.tag_configure("unpd",      foreground=RED)
        tree.tag_configure("completed", foreground=GREEN)
        tree.tag_configure("cancelled", foreground=RED)
        tree.tag_configure("scheduled", foreground=AMBER)
        tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        wrap.rowconfigure(0, weight=1); wrap.columnconfigure(0, weight=1)
        return tree

    def _fill(self, tree, rows):
        tree.delete(*tree.get_children())
        for i, row in enumerate(rows):
            tags = ("even",) if i % 2 == 0 else ("odd",)
            srow = [str(v) for v in row]
            if "Paid"      in srow: tags += ("paid",)
            if "Unpaid"    in srow: tags += ("unpd",)
            if "Completed" in srow: tags += ("completed",)
            if "Cancelled" in srow: tags += ("cancelled",)
            if "Scheduled" in srow: tags += ("scheduled",)
            tree.insert("", "end", values=srow, tags=tags)

    def _crud_toolbar(self, parent, on_add, on_edit, on_delete,
                      color=BRAND, add_label="Add New"):
        T = self.T
        bar = tk.Frame(parent, bg=T["BG"]); bar.pack(fill="x", padx=24, pady=(4, 2))
        RoundBtn(bar, f"➕ {add_label}", on_add, bg=color, fg=WHITE_FIXED).pack(side="left", padx=2)
        RoundBtn(bar, "✏ Edit",   on_edit,   bg=AMBER, fg=WHITE_FIXED).pack(side="left", padx=2)
        RoundBtn(bar, "🗑 Delete", on_delete, bg=RED,   fg=WHITE_FIXED).pack(side="left", padx=2)
        return bar

    def _section_lbl(self, parent, text, color):
        T = self.T
        f = tk.Frame(parent, bg=T["BG"]); f.pack(fill="x", padx=24, pady=(10, 2))
        tk.Frame(f, bg=color, width=3, height=16).pack(side="left")
        tk.Label(f, text=f" {text}", font=F_SUB, fg=T["TEXT"], bg=T["BG"]).pack(side="left")

    # def _chart_canvas(self, parent, fig):
    #     canvas = FigureCanvasTkAgg(fig, master=parent)
    #     canvas.draw()
    #     return canvas.get_tk_widget()

    # ─── All page methods imported from pages.py ──────────────────────────────
    from gui.pages import (
        _page_dashboard,
        _page_dashboard_admin,
        _page_dashboard_doctor,
        _page_my_patients,
        _page_my_appointments,
        _page_my_treatments,
        _page_patients,
        _page_doctors,
        _page_appts,
        _page_treatments,
        _page_billing,
        _page_reports,
        _page_profile,
    )
