"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  gui/pages.py — All page rendering methods (Mixin for MediCareHMS)         ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP → Mixin Pattern: Functions here become methods of MediCareHMS at runtime.
MVC → View Layer: Reads repos (Model), renders UI, wires user events.
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
import hashlib, uuid

from core.constants import (BRAND, RED, GREEN, AMBER, PURPLE, TEAL, PINK,
                              WHITE_FIXED, F_HUGE, F_HEAD, F_SUB, F_BODY,
                              F_SMALL, F_MONO, F_NAV)
from utils.helpers import RoundBtn, export_bill_pdf
from gui.dialogs import SMSDialog, PharmacySelectorDialog, EditDialog

# try:
#     import matplotlib.pyplot as plt
#     from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
#     HAS_MPLOT = True
# except ImportError:
#     HAS_MPLOT = False


# ══════════════════════════════════════════════════════
# DASHBOARD — Admin + Doctor
# ══════════════════════════════════════════════════════

def _page_dashboard(self):
    if self._is_doctor():
        self._page_dashboard_doctor()
    else:
        self._page_dashboard_admin()


def _page_dashboard_admin(self):
    T = self.T
    self._topbar("Dashboard",
                 f"Welcome, {self.current_user['full_name']} · {datetime.now().strftime('%A %d %B %Y')}")
    page = self._scrollable()
    grid = tk.Frame(page, bg=T["BG"]); grid.pack(fill="x", padx=14, pady=12)
    out_c, in_c = self.pat_repo.count_by_type()
    bills     = self.bill_repo.get_all()
    total_rev = self.bill_repo.total_revenue()
    paid_rev  = self.bill_repo.paid_revenue()
    cards = [
        ("Total Patients",  len(self.pat_repo.get_all()),   BRAND,  "#E8F1FD", "👤", 0),
        ("Outpatients",     out_c,                           TEAL,   "#E3FAFC", "🏥", 1),
        ("Inpatients",      in_c,                            PURPLE, "#F3F0FF", "🛏", 2),
        ("Total Doctors",   len(self.doc_repo.get_all()),    GREEN,  "#EBFBEE", "🩺", 3),
        ("Appointments",    len(self.appt_repo.get_all()),   AMBER,  "#FFF9DB", "📅", 4),
        ("Bills Generated", len(bills),                      PINK,   "#FFF0F6", "🧾", 5),
    ]
    for args in cards: self._stat_card(grid, *args)

    rev_f = tk.Frame(page, bg=T["CARD"]); rev_f.pack(fill="x", padx=24, pady=6)
    tk.Frame(rev_f, bg=BRAND, height=3).pack(fill="x")
    rb = tk.Frame(rev_f, bg=T["CARD"], padx=20, pady=12); rb.pack(fill="x")
    tk.Label(rb, text="💰 Financial Summary", font=F_SUB, fg=T["TEXT"], bg=T["CARD"]).pack(anchor="w", pady=(0, 8))
    rg = tk.Frame(rb, bg=T["CARD"]); rg.pack(fill="x")
    for i, (lbl, val, col) in enumerate([
        ("Total Revenue", f"LKR {total_rev:,.2f}", T["TEXT"]),
        ("Collected",     f"LKR {paid_rev:,.2f}",  GREEN),
        ("Outstanding",   f"LKR {total_rev-paid_rev:,.2f}", RED),
    ]):
        bx = tk.Frame(rg, bg=T["CARD2"], padx=16, pady=10)
        bx.grid(row=0, column=i, padx=8, sticky="ew"); rg.columnconfigure(i, weight=1)
        tk.Label(bx, text=lbl, font=F_SMALL, fg=T["TEXT2"], bg=T["CARD2"]).pack(anchor="w")
        tk.Label(bx, text=val, font=("Helvetica", 13, "bold"), fg=col, bg=T["CARD2"]).pack(anchor="w")

    self._section_lbl(page, "Today's Appointments", BRAND)
    cols = ["Appt ID", "Patient", "Doctor", "Type", "Time", "Reason", "Status"]
    tbl  = self._tree(page, cols, 4)
    self._fill(tbl, [[a["appointment_id"], a["patient_name"], a["doctor_name"],
                      a["appt_type"], a["time"], a["reason"], a["status"]]
                     for a in self.appt_repo.get_today()])


def _page_dashboard_doctor(self):
    T   = self.T
    did = self._get_doctor_id_for_user()
    doc = self.doc_repo.find_by_id(did) if did else None
    doc_name = doc["name"] if doc else self.current_user.get("full_name", "Doctor")
    self._topbar("My Dashboard", f"Welcome, {doc_name} · {datetime.now().strftime('%A %d %B %Y')}")
    page = self._scrollable()
    if not did:
        warn = tk.Frame(page, bg=T["CARD"]); warn.pack(fill="x", padx=24, pady=20)
        tk.Frame(warn, bg=AMBER, height=4).pack(fill="x")
        wb = tk.Frame(warn, bg=T["CARD"], padx=24, pady=20); wb.pack(fill="x")
        tk.Label(wb, text="⚠  No Doctor Record Linked", font=F_HEAD, fg=AMBER, bg=T["CARD"]).pack(anchor="w")
        tk.Label(wb, text="Ask Admin to link your account in the Doctors → Credentials panel.",
                 font=F_BODY, fg=T["TEXT2"], bg=T["CARD"]).pack(anchor="w", pady=(8, 0))
        return
    appts   = self.appt_repo.get_for_doctor(did)
    treats  = self.treat_repo.get_for_doctor(did)
    patients = self.pat_repo.get_for_doctor(did)
    today   = datetime.now().strftime("%Y-%m-%d")
    today_appts = [a for a in appts if a.get("date", "") == today]
    total_val   = sum(t.get("treatment_cost", 0) or 0 for t in treats)
    grid = tk.Frame(page, bg=T["BG"]); grid.pack(fill="x", padx=24, pady=12)
    for i, (lbl, val, col, icon) in enumerate([
        ("My Patients",          len(patients),                    BRAND,  "👤"),
        ("Today's Appointments", len(today_appts),                 AMBER,  "📅"),
        ("Total Appointments",   len(appts),                       TEAL,   "🗓"),
        ("Treatment Records",    len(treats),                      GREEN,  "💊"),
        ("Treatment Value",      f"LKR {total_val:,.0f}",          PURPLE, "💰"),
        ("Completed Today",      sum(1 for a in today_appts if a["status"]=="Completed"), PINK, "✅"),
    ]):
        card = tk.Frame(grid, bg=T["CARD"]); card.grid(row=0, column=i, padx=4, pady=4, sticky="ew")
        grid.columnconfigure(i, weight=1)
        tk.Frame(card, bg=col, height=4).pack(fill="x")
        body = tk.Frame(card, bg=T["CARD"], padx=12, pady=10); body.pack(fill="x")
        tk.Label(body, text=icon, font=("Helvetica", 16), fg=col, bg=T["CARD"]).pack(side="right")
        tk.Label(body, text=str(val), font=("Helvetica", 18, "bold"), fg=T["TEXT"], bg=T["CARD"]).pack(anchor="w")
        tk.Label(body, text=lbl, font=("Helvetica", 8), fg=T["TEXT2"], bg=T["CARD"]).pack(anchor="w")
    self._section_lbl(page, f"Today's Schedule — {datetime.now().strftime('%d %B %Y')}", AMBER)
    cols = ["Appt ID", "Patient", "Type", "Time", "Reason", "Status"]
    tbl  = self._tree(page, cols, 5)
    self._fill(tbl, [[a["appointment_id"], a["patient_name"], a["appt_type"],
                      a["time"], a["reason"], a["status"]] for a in today_appts])
    self._section_lbl(page, "Recent Treatment Records", GREEN)
    tcols = ["Treatment ID", "Patient", "Diagnosis", "Cost (LKR)", "Date"]
    ttbl  = self._tree(page, tcols, 4)
    self._fill(ttbl, [[t["treatment_id"], t["patient_name"], t["diagnosis"],
                       f"{t['treatment_cost']:,.2f}", t["date"]] for t in treats[:8]])


def _page_my_patients(self):
    T   = self.T
    did = self._get_doctor_id_for_user()
    if not did:
        self._topbar("My Patients", "No doctor record linked")
        page = self._scrollable()
        tk.Label(page, text="⚠ No doctor record linked. Contact Admin.",
                 font=F_HEAD, fg=AMBER, bg=T["BG"]).pack(pady=40); return
    doc      = self.doc_repo.find_by_id(did)
    doc_name = doc["name"] if doc else "Unknown"
    patients = self.pat_repo.get_for_doctor(did)
    self._topbar("My Patients", f"Dr. {doc_name} — {len(patients)} unique patients")
    page = self._scrollable()
    self._section_lbl(page, f"Patients Under Dr. {doc_name}", BRAND)
    cols = ["Patient ID", "Name", "Age", "Gender", "Blood", "Type", "Phone", "Address", "Registered"]
    tree = self._tree(page, cols)
    self._fill(tree, [[p["patient_id"], p["name"], p["age"], p["gender"], p["blood_group"],
                       p["patient_type"], p["phone"], p["address"], p["created_at"]]
                      for p in patients])


def _page_my_appointments(self):
    T   = self.T
    did = self._get_doctor_id_for_user()
    if not did:
        self._topbar("My Appointments", "No doctor record linked")
        page = self._scrollable()
        tk.Label(page, text="⚠ No doctor record linked. Contact Admin.",
                 font=F_HEAD, fg=AMBER, bg=T["BG"]).pack(pady=40); return
    doc      = self.doc_repo.find_by_id(did)
    doc_name = doc["name"] if doc else "Unknown"
    appts    = self.appt_repo.get_for_doctor(did)
    self._topbar("My Appointments", f"Dr. {doc_name} — {len(appts)} appointments")
    outer   = tk.Frame(self.content, bg=T["BG"]); outer.pack(fill="both", expand=True)
    toolbar = tk.Frame(outer, bg=T["BG"], padx=16, pady=8); toolbar.pack(fill="x")
    tk.Label(toolbar, text="📅 My Appointments", font=F_SUB, fg=T["TEXT"], bg=T["BG"]).pack(side="left")
    atypes   = ["Outpatient Consultation", "Inpatient Review", "Follow-up", "Emergency", "Teleconsultation"]
    statuses = ["Scheduled", "Completed", "Cancelled", "No-Show"]
    filter_v = tk.StringVar(value="All")
    tk.Label(toolbar, text="  Filter:", font=F_SMALL, fg=T["TEXT2"], bg=T["BG"]).pack(side="left", padx=(20, 4))
    filter_cb = ttk.Combobox(toolbar, textvariable=filter_v,
                              values=["All","Scheduled","Completed","Cancelled","No-Show"],
                              font=F_BODY, state="readonly", width=14)
    filter_cb.pack(side="left")
    cols = ["Appt ID","Patient","Phone","Type","Date","Time","Reason","Status"]
    tree_wrap = tk.Frame(outer, bg=T["CARD"]); tree_wrap.pack(fill="both", expand=True, padx=16, pady=(4,0))
    tree = ttk.Treeview(tree_wrap, columns=cols, show="headings", height=14)
    vsb  = ttk.Scrollbar(tree_wrap, orient="vertical", command=tree.yview)
    hsb  = ttk.Scrollbar(tree_wrap, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
    for col in cols:
        tree.heading(col, text=col)
        w = 100 if col in ("Appt ID","Date","Time","Phone") else 80 if col=="Status" else 120
        tree.column(col, width=w, minwidth=50, anchor="center")
    tree.tag_configure("even", background=T["TREE_ROW"]); tree.tag_configure("odd", background=T["TREE_ROW2"])
    tree.tag_configure("completed", foreground=GREEN)
    tree.tag_configure("cancelled", foreground=RED)
    tree.tag_configure("scheduled", foreground=AMBER)
    tree.grid(row=0, column=0, sticky="nsew"); vsb.grid(row=0, column=1, sticky="ns")
    hsb.grid(row=1, column=0, sticky="ew")
    tree_wrap.rowconfigure(0, weight=1); tree_wrap.columnconfigure(0, weight=1)

    def refresh(filter_status="All"):
        tree.delete(*tree.get_children())
        for i, a in enumerate(self.appt_repo.get_for_doctor(did)):
            if filter_status != "All" and a["status"] != filter_status: continue
            tags = ("even",) if i%2==0 else ("odd",)
            st = a["status"]
            if st=="Completed": tags+=("completed",)
            elif st=="Cancelled": tags+=("cancelled",)
            elif st=="Scheduled": tags+=("scheduled",)
            tree.insert("", "end", values=(
                a["appointment_id"], a["patient_name"], a.get("patient_phone","—"),
                a["appt_type"], a["date"], a["time"], a["reason"], a["status"]), tags=tags)

    filter_cb.bind("<<ComboboxSelected>>", lambda e: refresh(filter_v.get()))
    refresh()

    action = tk.Frame(outer, bg=T["CARD"]); action.pack(fill="x", padx=16, pady=6)
    tk.Frame(action, bg=AMBER, height=3).pack(fill="x")
    ab = tk.Frame(action, bg=T["CARD"], padx=16, pady=10); ab.pack(fill="x")
    tk.Label(ab, text="⚡ Quick Actions — Select an appointment first:",
             font=F_SUB, fg=T["TEXT"], bg=T["CARD"]).pack(anchor="w", pady=(0,8))

    def get_selected():
        sel = tree.focus()
        if not sel: messagebox.showwarning("Select", "Select an appointment.", parent=self); return None
        return tree.item(sel, "values")

    def confirm_appt():
        vals = get_selected()
        if not vals: return
        aid  = vals[0]; appt = self.appt_repo.find_by_id(aid)
        if not appt: return
        self.appt_repo.update_status(aid, "Completed"); refresh(filter_v.get())
        SMSDialog(self, appt["patient_name"], appt.get("patient_phone","N/A"),
                  appt["time"], appt["date"], appt["doctor_name"], "Completed")

    def cancel_appt():
        vals = get_selected()
        if not vals: return
        aid  = vals[0]; appt = self.appt_repo.find_by_id(aid)
        if not appt: return
        if not messagebox.askyesno("Confirm", f"Cancel appointment {aid}?", parent=self): return
        self.appt_repo.update_status(aid, "Cancelled"); refresh(filter_v.get())
        SMSDialog(self, appt["patient_name"], appt.get("patient_phone","N/A"),
                  appt["time"], appt["date"], appt["doctor_name"], "Cancelled")

    def no_show():
        vals = get_selected()
        if not vals: return
        self.appt_repo.update_status(vals[0], "No-Show"); refresh(filter_v.get())
        messagebox.showinfo("Updated", "Appointment marked as No-Show.", parent=self)

    btn_row = tk.Frame(ab, bg=T["CARD"]); btn_row.pack(fill="x")
    RoundBtn(btn_row, "✅ Confirm", confirm_appt, bg=GREEN, fg=WHITE_FIXED).pack(side="left", padx=(0,4))
    RoundBtn(btn_row, "❌ Cancel",  cancel_appt,  bg=RED,   fg=WHITE_FIXED).pack(side="left", padx=(0,4))
    RoundBtn(btn_row, "👻 No-Show", no_show,      bg="#6B7280", fg=WHITE_FIXED).pack(side="left", padx=(0,4))


def _page_my_treatments(self):
    T   = self.T
    did = self._get_doctor_id_for_user()
    if not did:
        self._topbar("My Treatments", "No doctor record linked")
        page = self._scrollable()
        tk.Label(page, text="⚠ No doctor record linked. Contact Admin.",
                 font=F_HEAD, fg=AMBER, bg=T["BG"]).pack(pady=40); return
    doc      = self.doc_repo.find_by_id(did)
    doc_name = doc["name"] if doc else "Unknown"
    treats   = self.treat_repo.get_for_doctor(did)
    total_val = sum(t.get("treatment_cost",0) or 0 for t in treats)
    self._topbar("My Treatments", f"Dr. {doc_name} — {len(treats)} records · LKR {total_val:,.2f}")
    page = self._scrollable()
    self._section_lbl(page, f"Treatment Records — Dr. {doc_name}", GREEN)
    cols = ["Treatment ID","Patient","Diagnosis","Medication","Lab Tests","Cost (LKR)","Date"]
    tree = self._tree(page, cols)
    self._fill(tree, [[t["treatment_id"], t["patient_name"], t["diagnosis"],
                       t["medication"] or "—", t["lab_tests"] or "—",
                       f"{t['treatment_cost']:,.2f}", t["date"]] for t in treats])


def _page_patients(self):
    color = PURPLE; T = self.T
    pts = self.pat_repo.get_all()
    self._topbar("Patient Management", f"Total: {len(pts)} patients")
    page = self._scrollable()
    frm  = self._form_card(page, "➕ Register New Patient", color)
    genders = ["Male","Female","Other"]
    bloods  = ["A+","A-","B+","B-","AB+","AB-","O+","O-","Unknown"]
    ptypes  = ["Outpatient","Inpatient"]
    fv = {k: tk.StringVar() for k in ["name","age","gender","phone","address","blood","ptype"]}
    fv["gender"].set("Male"); fv["blood"].set("Unknown"); fv["ptype"].set("Outpatient")
    self._lbl_entry(frm, "Full Name *", 0, 0, fv["name"], color)
    self._lbl_entry(frm, "Age *",       0, 1, fv["age"],  color, 10)
    self._lbl_combo(frm, "Gender",      0, 2, fv["gender"], genders, color, 12)
    self._lbl_entry(frm, "Phone",       1, 0, fv["phone"], color)
    self._lbl_entry(frm, "Address",     1, 1, fv["address"], color)
    self._lbl_combo(frm, "Blood Group", 1, 2, fv["blood"], bloods, color, 12)
    self._lbl_combo(frm, "Patient Type",2, 0, fv["ptype"], ptypes, color, 14)
    search_v = tk.StringVar()

    def do_add():
        if not fv["name"].get().strip():
            messagebox.showerror("Error", "Name required!", parent=self); return
        try: age = int(fv["age"].get()); assert 0 < age < 130
        except: messagebox.showerror("Error", "Valid age (1-129) required.", parent=self); return
        self.pat_repo.add({"name": fv["name"].get().strip(), "age": age,
                            "gender": fv["gender"].get(), "phone": fv["phone"].get().strip(),
                            "address": fv["address"].get().strip(), "blood": fv["blood"].get(),
                            "ptype": fv["ptype"].get()})
        for v in fv.values(): v.set("")
        fv["gender"].set("Male"); fv["blood"].set("Unknown"); fv["ptype"].set("Outpatient")
        refresh(); messagebox.showinfo("✅ Added", "Patient registered!", parent=self)

    def refresh():
        q    = search_v.get().strip()
        data = self.pat_repo.search(q) if q else self.pat_repo.get_all()
        self._fill(tree, [[p["patient_id"],p["name"],p["age"],p["gender"],p["blood_group"],
                           p["patient_type"],p["phone"],p["address"],p["created_at"]] for p in data])

    def do_edit():
        sel = tree.focus()
        if not sel: messagebox.showwarning("Select", "Select a patient.", parent=self); return
        pid = tree.item(sel,"values")[0]; pat = self.pat_repo.find_by_id(pid)
        fields = [("name","Full Name","entry",None),("age","Age","entry",None),
                  ("gender","Gender","combo",genders),("phone","Phone","entry",None),
                  ("address","Address","entry",None),("blood_group","Blood Group","combo",bloods),
                  ("patient_type","Patient Type","combo",ptypes)]
        def save(d):
            try: age = int(d["age"]); assert 0 < age < 130
            except: messagebox.showerror("Error","Invalid age.",parent=self); return
            self.pat_repo.update(pid, {"name":d["name"],"age":age,"gender":d["gender"],
                "phone":d["phone"],"address":d["address"],"blood":d["blood_group"],"ptype":d["patient_type"]})
            refresh()
        EditDialog(self, f"Edit Patient — {pid}", fields, pat, save, color, T)

    def do_delete():
        sel = tree.focus()
        if not sel: messagebox.showwarning("Select","Select a patient.",parent=self); return
        vals = tree.item(sel,"values")
        if messagebox.askyesno("Confirm",f"Delete {vals[1]} ({vals[0]})?",parent=self):
            self.pat_repo.delete(vals[0]); refresh()

    sb = tk.Frame(page, bg=T["BG"]); sb.pack(fill="x", padx=24, pady=(4,2))
    tk.Label(sb, text="🔍", font=F_SMALL, fg=T["TEXT2"], bg=T["BG"]).pack(side="left")
    se = tk.Entry(sb, textvariable=search_v, font=F_BODY, bg=T["CARD"], fg=T["TEXT"],
                  bd=0, highlightthickness=1, highlightbackground=T["BORDER"],
                  highlightcolor=color, insertbackground=color, width=36)
    se.pack(side="left", padx=8, ipady=6)
    se.bind("<KeyRelease>", lambda e: refresh())
    RoundBtn(sb, "➕ Add Patient", do_add, bg=color, fg=WHITE_FIXED).pack(side="left", padx=4)
    self._crud_toolbar(page, do_add, do_edit, do_delete, color, "Add Patient")
    cols = ["Patient ID","Name","Age","Gender","Blood","Type","Phone","Address","Registered"]
    tree = self._tree(page, cols); refresh()


def _page_doctors(self):
    color = TEAL; T = self.T
    all_docs = self.doc_repo.get_all()
    self._topbar("Doctor Management", f"Total: {len(all_docs)} doctors registered")
    outer = tk.Frame(self.content, bg=T["BG"]); outer.pack(fill="both", expand=True)
    outer.columnconfigure(0, weight=5); outer.columnconfigure(1, weight=4); outer.rowconfigure(0, weight=1)
    left_col = tk.Frame(outer, bg=T["BG"]); left_col.grid(row=0, column=0, sticky="nsew", padx=(10,4), pady=10)
    form_card = tk.Frame(left_col, bg=T["CARD"]); form_card.pack(fill="x", pady=(0,8))
    tk.Frame(form_card, bg=TEAL, height=4).pack(fill="x")
    fh = tk.Frame(form_card, bg=T["CARD"], padx=16, pady=10); fh.pack(fill="x")
    tk.Label(fh, text="➕  Register New Doctor", font=("Helvetica",11,"bold"), fg=TEAL, bg=T["CARD"]).pack(side="left")
    tk.Frame(form_card, bg=T["BORDER"], height=1).pack(fill="x")
    fb = tk.Frame(form_card, bg=T["CARD"], padx=16, pady=12); fb.pack(fill="x")
    fb.columnconfigure(0,weight=1); fb.columnconfigure(1,weight=1); fb.columnconfigure(2,weight=1)
    genders = ["Male","Female","Other"]
    specs   = ["Cardiology","Neurology","Orthopedics","Pediatrics","General Medicine",
               "Dermatology","ENT","Ophthalmology","Psychiatry","Radiology","Oncology","Urology","Gynecology"]
    fv = {k: tk.StringVar() for k in ["name","age","gender","phone","spec","fee","regno"]}
    fv["gender"].set("Male")

    def fl(p,t,r,c): tk.Label(p,text=t,font=("Helvetica",8,"bold"),fg=T["TEXT2"],bg=T["CARD"]).grid(row=r*2,column=c,sticky="w",padx=(0,8),pady=(6,2))
    def fe(p,v,r,c,w=16):
        e=tk.Entry(p,textvariable=v,font=F_BODY,bg=T["INPUT_BG"],fg=T["TEXT"],bd=0,
                   highlightthickness=1,highlightbackground=T["BORDER"],highlightcolor=TEAL,
                   insertbackground=TEAL,width=w); e.grid(row=r*2+1,column=c,sticky="ew",padx=(0,8),pady=(0,4)); return e
    def fc(p,v,vs,r,c,w=14):
        cb=ttk.Combobox(p,textvariable=v,values=vs,font=F_BODY,state="readonly",width=w)
        cb.grid(row=r*2+1,column=c,sticky="ew",padx=(0,8),pady=(0,4)); return cb

    fl(fb,"Full Name *",0,0); fe(fb,fv["name"],0,0)
    fl(fb,"Age *",0,1);       fe(fb,fv["age"],0,1,6)
    fl(fb,"Gender",0,2);      fc(fb,fv["gender"],genders,0,2,10)
    fl(fb,"Phone",1,0);       fe(fb,fv["phone"],1,0)
    fl(fb,"Specialization",1,1); fc(fb,fv["spec"],specs,1,1,16)
    fl(fb,"Consult Fee (LKR)",1,2); fe(fb,fv["fee"],1,2,10)
    fl(fb,"SLMC Reg No",2,0); fe(fb,fv["regno"],2,0)
    add_msg = tk.Label(fb,text="",font=F_SMALL,bg=T["CARD"])
    add_msg.grid(row=6,column=0,columnspan=3,sticky="w",pady=(4,0))

    def do_add():
        if not fv["name"].get().strip(): add_msg.config(text="⚠ Name required.",fg=RED); return
        try: age=int(fv["age"].get()); assert 0<age<100; fee=float(fv["fee"].get())
        except: add_msg.config(text="⚠ Invalid age or fee.",fg=RED); return
        self.doc_repo.add({"name":fv["name"].get().strip(),"age":age,"gender":fv["gender"].get(),
            "phone":fv["phone"].get().strip(),"spec":fv["spec"].get(),"fee":fee,"regno":fv["regno"].get().strip()})
        for v in fv.values(): v.set("")
        fv["gender"].set("Male")
        add_msg.config(text="✅ Doctor registered!",fg=GREEN); refresh()

    RoundBtn(fb,"➕  Add Doctor",do_add,bg=TEAL,fg=WHITE_FIXED,font=("Helvetica",9,"bold")).grid(row=7,column=0,columnspan=2,sticky="w",pady=(8,0))
    tb = tk.Frame(left_col, bg=T["BG"]); tb.pack(fill="x", pady=(0,4))

    def do_edit():
        sel = tree.focus()
        if not sel: messagebox.showwarning("Select","Select a doctor.",parent=self); return
        did = tree.item(sel,"values")[0]; doc = self.doc_repo.find_by_id(did)
        fields = [("name","Full Name","entry",None),("age","Age","entry",None),
                  ("gender","Gender","combo",genders),("phone","Phone","entry",None),
                  ("specialization","Specialization","combo",specs),
                  ("fee","Consult Fee","entry",None),("reg_no","SLMC Reg No","entry",None)]
        def save(d):
            try: age=int(d["age"]); fee=float(d["fee"])
            except: messagebox.showerror("Error","Invalid age or fee.",parent=self); return
            self.doc_repo.update(did,{"name":d["name"],"age":age,"gender":d["gender"],
                "phone":d["phone"],"spec":d["specialization"],"fee":fee,"regno":d["reg_no"]})
            refresh(reselect_did=did)
            _build_profile(did)
        EditDialog(self,f"Edit Doctor — {did}",fields,doc,save,TEAL,T)

    def do_delete():
        sel = tree.focus()
        if not sel: messagebox.showwarning("Select","Select a doctor.",parent=self); return
        vals = tree.item(sel,"values")
        if messagebox.askyesno("Confirm",f"Delete Dr. {vals[1]}?",parent=self):
            self.doc_repo.delete(vals[0])
            # Clear right panel back to placeholder
            for w in ph_frame.master.winfo_children():
                w.pack_forget()
            ph_frame.pack(fill="both", expand=True)
            refresh()

    RoundBtn(tb,"✏  Edit",do_edit,bg=AMBER,fg=WHITE_FIXED).pack(side="left",padx=(0,4))
    RoundBtn(tb,"🗑  Delete",do_delete,bg=RED,fg=WHITE_FIXED).pack(side="left")

    tbl_card = tk.Frame(left_col, bg=T["CARD"]); tbl_card.pack(fill="both", expand=True)
    tk.Frame(tbl_card, bg=TEAL, height=3).pack(fill="x")
    th2 = tk.Frame(tbl_card, bg=T["CARD"], padx=12, pady=8); th2.pack(fill="x")
    tk.Label(th2, text="🩺  All Doctors", font=F_SUB, fg=TEAL, bg=T["CARD"]).pack(side="left")
    count_lbl = tk.Label(th2, text="", font=F_SMALL, fg=T["TEXT2"], bg=T["CARD"]); count_lbl.pack(side="right")
    tk.Frame(tbl_card, bg=T["BORDER"], height=1).pack(fill="x")
    tcols = ["ID","Name","Specialization","Reg No","Gender","Age","Fee (LKR)","Phone"]
    tree  = ttk.Treeview(tbl_card, columns=tcols, show="headings", height=12)
    vsb   = ttk.Scrollbar(tbl_card, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=vsb.set)
    col_widths = {"ID":90,"Name":130,"Specialization":110,"Reg No":90,"Gender":60,"Age":40,"Fee (LKR)":80,"Phone":100}
    for col in tcols:
        tree.heading(col, text=col)
        tree.column(col, width=col_widths.get(col,90), minwidth=40, anchor="w" if col in ("Name","Specialization") else "center")
    tree.tag_configure("even", background=T["TREE_ROW"]); tree.tag_configure("odd", background=T["TREE_ROW2"])
    vsb.pack(side="right", fill="y", padx=(0,4), pady=4)
    tree.pack(fill="both", expand=True, padx=4, pady=4)

    # ── RIGHT PANEL: Doctor Profile + Login Credentials ─────────────────────
    right_col = tk.Frame(outer, bg=T["BG"]); right_col.grid(row=0, column=1, sticky="nsew", padx=(4,10), pady=10)
    right_col.rowconfigure(0, weight=1); right_col.columnconfigure(0, weight=1)

    # Scrollable right panel
    rc_canvas = tk.Canvas(right_col, bg=T["BG"], bd=0, highlightthickness=0)
    rc_vsb    = ttk.Scrollbar(right_col, orient="vertical", command=rc_canvas.yview)
    rc_canvas.configure(yscrollcommand=rc_vsb.set)
    rc_vsb.pack(side="right", fill="y"); rc_canvas.pack(fill="both", expand=True)
    rc_inner = tk.Frame(rc_canvas, bg=T["BG"])
    rc_win   = rc_canvas.create_window((0,0), window=rc_inner, anchor="nw")
    rc_inner.bind("<Configure>", lambda e: rc_canvas.configure(scrollregion=rc_canvas.bbox("all")))
    rc_canvas.bind("<Configure>", lambda e: rc_canvas.itemconfig(rc_win, width=e.width))

    # ── Placeholder shown when no doctor is selected ──────────────────────
    ph_frame = tk.Frame(rc_inner, bg=T["CARD"]); ph_frame.pack(fill="both", expand=True, pady=(0,8))
    tk.Frame(ph_frame, bg=TEAL, height=4).pack(fill="x")
    ph_inner2 = tk.Frame(ph_frame, bg=T["CARD"]); ph_inner2.pack(fill="both", expand=True, pady=40)
    ph_icon = tk.Label(ph_inner2, text="🩺", font=("Helvetica",40), fg=T["BORDER"], bg=T["CARD"])
    ph_icon.pack(pady=(40,10))
    ph_lbl  = tk.Label(ph_inner2, text="Select a doctor to view profile\n& manage login credentials",
                       font=("Helvetica",11), fg=T["BORDER"], bg=T["CARD"], justify="center")
    ph_lbl.pack()

    # ── Profile card (hidden until doctor selected) ───────────────────────
    prof_frame = tk.Frame(rc_inner, bg=T["BG"]); # packed dynamically

    def _build_profile(did):
        """Build and show doctor profile + user credential panel."""
        doc  = self.doc_repo.find_by_id(did)
        if not doc: return
        user = self.db.fetchone("SELECT * FROM users WHERE doctor_id=?", (did,))

        # Clear old profile widgets
        for w in prof_frame.winfo_children(): w.destroy()
        ph_frame.pack_forget()
        prof_frame.pack(fill="both", expand=True)

        # ── Profile Info Card ─────────────────────────────────────────────
        info_card = tk.Frame(prof_frame, bg=T["CARD"]); info_card.pack(fill="x", pady=(0,8))
        tk.Frame(info_card, bg=TEAL, height=4).pack(fill="x")
        ih = tk.Frame(info_card, bg=T["CARD"], padx=14, pady=10); ih.pack(fill="x")
        tk.Label(ih, text="👨‍⚕️  Doctor Profile", font=("Helvetica",11,"bold"), fg=TEAL, bg=T["CARD"]).pack(side="left")
        tk.Label(ih, text=doc["doctor_id"], font=F_MONO, fg=T["TEXT2"], bg=T["CARD"]).pack(side="right")
        tk.Frame(info_card, bg=T["BORDER"], height=1).pack(fill="x")

        ib = tk.Frame(info_card, bg=T["CARD"], padx=14, pady=12); ib.pack(fill="x")
        def info_row(lbl, val, clr=T["TEXT"]):
            row = tk.Frame(ib, bg=T["CARD"]); row.pack(fill="x", pady=2)
            tk.Label(row, text=lbl, font=("Helvetica",8,"bold"), fg=T["TEXT2"],
                     bg=T["CARD"], width=16, anchor="w").pack(side="left")
            tk.Label(row, text=str(val) if val else "—", font=F_BODY,
                     fg=clr, bg=T["CARD"], anchor="w").pack(side="left", padx=(4,0))

        info_row("Name",           doc["name"],           TEAL)
        info_row("Specialization", doc["specialization"])
        info_row("Age / Gender",   f"{doc['age']} / {doc['gender']}")
        info_row("Phone",          doc.get("phone","—"))
        info_row("SLMC Reg No",    doc.get("reg_no","—"))
        info_row("Consult Fee",    f"LKR {doc.get('fee',0):,.2f}")
        info_row("Registered On",  doc.get("created_at","—")[:10] if doc.get("created_at") else "—")

        has_user = user is not None
        info_row("Login Account",  "✅ Active" if has_user else "❌ Not Created",
                 GREEN if has_user else RED)
        if has_user:
            info_row("Username",   user["username"])
            info_row("Role",       user.get("role","Doctor"))

        # ── User / Password Management Card ──────────────────────────────
        cred_card = tk.Frame(prof_frame, bg=T["CARD"]); cred_card.pack(fill="x", pady=(0,8))
        tk.Frame(cred_card, bg=TEAL, height=4).pack(fill="x")
        ch = tk.Frame(cred_card, bg=T["CARD"], padx=14, pady=10); ch.pack(fill="x")
        title_txt = "🔑  Update Login Credentials" if has_user else "🔑  Create Login Account"
        tk.Label(ch, text=title_txt, font=("Helvetica",11,"bold"), fg=TEAL, bg=T["CARD"]).pack(side="left")
        tk.Frame(cred_card, bg=T["BORDER"], height=1).pack(fill="x")

        cb = tk.Frame(cred_card, bg=T["CARD"], padx=14, pady=14); cb.pack(fill="x")

        def clbl(t): tk.Label(cb, text=t, font=("Helvetica",8,"bold"), fg=T["TEXT2"],
                               bg=T["CARD"], anchor="w").pack(fill="x", pady=(8,2))
        def cent(sv, show=""):
            e = tk.Entry(cb, textvariable=sv, font=F_BODY,
                         bg=T["INPUT_BG"], fg=T["TEXT"], bd=0,
                         highlightthickness=1, highlightbackground=T["BORDER"],
                         highlightcolor=TEAL, insertbackground=TEAL,
                         show=show, width=28)
            e.pack(fill="x", ipady=6, pady=(0,2)); return e

        uv  = tk.StringVar(value=user["username"] if has_user else "")
        pv  = tk.StringVar()
        cpv = tk.StringVar()
        msg_lbl = tk.Label(cb, text="", font=F_SMALL, bg=T["CARD"]); 

        clbl("Username *"); cent(uv)
        clbl("New Password *"); cent(pv, show="●")
        clbl("Confirm Password *"); cent(cpv, show="●")
        msg_lbl.pack(fill="x", pady=(4,0))

        def do_save_credentials():
            username = uv.get().strip()
            pw       = pv.get()
            cpw      = cpv.get()

            # ── Validation ────────────────────────────────────────────────
            if not username:
                msg_lbl.config(text="⚠  Username is required.", fg=RED); return
            if len(username) < 3:
                msg_lbl.config(text="⚠  Username must be at least 3 characters.", fg=RED); return
            if not pw:
                msg_lbl.config(text="⚠  Password is required.", fg=RED); return
            if len(pw) < 6:
                msg_lbl.config(text="⚠  Password must be at least 6 characters.", fg=RED); return
            if pw != cpw:
                msg_lbl.config(text="⚠  Passwords do not match.", fg=RED); return

            import hashlib, uuid
            hashed = hashlib.sha256(pw.encode()).hexdigest()

            if has_user:
                # ── UPDATE existing user ──────────────────────────────────
                # Check username conflict (another user already has this name)
                conflict = self.db.fetchone(
                    "SELECT id FROM users WHERE username=? AND id!=?",
                    (username, user["id"]))
                if conflict:
                    msg_lbl.config(text="⚠  Username already taken.", fg=RED); return
                self.db.exe(
                    "UPDATE users SET username=?, password=? WHERE id=?",
                    (username, hashed, user["id"]))
                msg_lbl.config(text="✅  Credentials updated successfully!", fg=GREEN)
            else:
                # ── CREATE new user account for this doctor ───────────────
                conflict = self.db.fetchone(
                    "SELECT id FROM users WHERE username=?", (username,))
                if conflict:
                    msg_lbl.config(text="⚠  Username already taken.", fg=RED); return
                from datetime import datetime
                now = datetime.now().strftime("%Y-%m-%d %H:%M")
                uid = str(uuid.uuid4())[:8].upper()
                self.db.exe(
                    "INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (uid, username, hashed, doc["name"], "Doctor",
                     doc["specialization"], doc.get("phone",""),
                     "", now, "light", did))
                msg_lbl.config(text="✅  Login account created successfully!", fg=GREEN)

            pv.set(""); cpv.set("")
            # Rebuild profile immediately to reflect changes (no delay needed)
            refresh(reselect_did=did)
            _build_profile(did)

        def do_remove_account():
            if not has_user:
                msg_lbl.config(text="⚠  No account to remove.", fg=RED); return
            if not messagebox.askyesno("Confirm",
                f"Remove login account for Dr. {doc['name']}?\n\nThey will no longer be able to log in.",
                parent=self): return
            self.db.exe("DELETE FROM users WHERE id=?", (user["id"],))
            # Rebuild immediately to show 'Create Account' form
            refresh(reselect_did=did)
            _build_profile(did)

        btn_row = tk.Frame(cb, bg=T["CARD"]); btn_row.pack(fill="x", pady=(12,0))
        save_txt = "🔑  Update Credentials" if has_user else "✅  Create Account"
        RoundBtn(btn_row, save_txt,          do_save_credentials,
                 bg=TEAL,  fg=WHITE_FIXED).pack(side="left", padx=(0,6))
        if has_user:
            RoundBtn(btn_row, "🗑  Remove Account", do_remove_account,
                     bg=RED, fg=WHITE_FIXED).pack(side="left")

    # ── Tree selection event ──────────────────────────────────────────────
    def on_tree_select(event):
        sel = tree.focus()
        if not sel: return
        did = tree.item(sel, "values")[0]
        _build_profile(did)

    def refresh(reselect_did=None):
        rows = self.doc_repo.get_all_with_users()
        tree.delete(*tree.get_children())
        target_item = None
        for i, d in enumerate(rows):
            tags = ("even",) if i % 2 == 0 else ("odd",)
            iid = tree.insert("", "end", values=(
                d["doctor_id"], d["name"], d["specialization"],
                d.get("reg_no","—"), d["gender"], d["age"],
                f"{d['fee']:,.2f}", d.get("phone","—")), tags=tags)
            if reselect_did and d["doctor_id"] == reselect_did:
                target_item = iid
        count_lbl.config(text=f"{len(rows)} doctors")
        # Restore selection if a doctor was previously selected
        if target_item:
            tree.selection_set(target_item)
            tree.focus(target_item)
        tree.bind("<<TreeviewSelect>>", on_tree_select)

    refresh()
    tree.bind("<<TreeviewSelect>>", on_tree_select)


def _page_appts(self):
    color = AMBER; T = self.T
    self._topbar("Appointment Management", f"Total: {len(self.appt_repo.get_all())} appointments")
    page   = self._scrollable()
    frm    = self._form_card(page, "📅 Book New Appointment", color)
    pts    = self.pat_repo.get_all(); docs = self.doc_repo.get_all()
    pat_opts = [f"{p['patient_id']} — {p['name']}" for p in pts]
    doc_opts = [f"{d['doctor_id']} — {d['name']} ({d['specialization']})" for d in docs]
    atypes   = ["Outpatient Consultation","Inpatient Review","Follow-up","Emergency","Teleconsultation"]
    statuses = ["Scheduled","Completed","Cancelled","No-Show"]
    fv = {k: tk.StringVar() for k in ["pat","doc","date","time","reason","atype"]}
    fv["date"].set(datetime.now().strftime("%Y-%m-%d")); fv["time"].set("09:00 AM")
    fv["atype"].set("Outpatient Consultation")
    self._lbl_combo(frm,"Patient *",0,0,fv["pat"],pat_opts,color,36)
    self._lbl_combo(frm,"Doctor *", 0,1,fv["doc"],doc_opts,color,36)
    self._lbl_entry(frm,"Date (YYYY-MM-DD)",1,0,fv["date"],color)
    self._lbl_entry(frm,"Time",1,1,fv["time"],color)
    self._lbl_combo(frm,"Type",2,0,fv["atype"],atypes,color,28)
    self._lbl_entry(frm,"Reason",2,1,fv["reason"],color)

    def do_add():
        if not fv["pat"].get() or not fv["doc"].get():
            messagebox.showerror("Error","Select patient and doctor.",parent=self); return
        pid=fv["pat"].get().split(" — ")[0]; did=fv["doc"].get().split(" — ")[0]
        self.appt_repo.add({"patient_id":pid,"doctor_id":did,"date":fv["date"].get().strip(),
            "time":fv["time"].get().strip(),"reason":fv["reason"].get().strip(),"atype":fv["atype"].get()})
        fv["date"].set(datetime.now().strftime("%Y-%m-%d")); fv["time"].set("09:00 AM")
        fv["atype"].set("Outpatient Consultation"); fv["reason"].set("")
        refresh(); messagebox.showinfo("✅ Booked","Appointment booked!",parent=self)

    def refresh():
        self._fill(tree,[[a["appointment_id"],a["patient_name"],a["doctor_name"],
            a["appt_type"],a["date"],a["time"],a["reason"],a["status"]]
            for a in self.appt_repo.get_all()])

    def do_edit():
        sel=tree.focus()
        if not sel: messagebox.showwarning("Select","Select an appointment.",parent=self); return
        aid=tree.item(sel,"values")[0]; appt=self.appt_repo.find_by_id(aid)
        fields=[("date","Date","entry",None),("time","Time","entry",None),
                ("reason","Reason","entry",None),("appt_type","Type","combo",atypes),
                ("status","Status","combo",statuses)]
        def save(d):
            self.appt_repo.update(aid,{"date":d["date"],"time":d["time"],"reason":d["reason"],
                "atype":d["appt_type"],"status":d["status"]}); refresh()
        EditDialog(self,f"Edit Appointment — {aid}",fields,appt,save,color,T)

    def do_delete():
        sel=tree.focus()
        if not sel: messagebox.showwarning("Select","Select an appointment.",parent=self); return
        vals=tree.item(sel,"values")
        if messagebox.askyesno("Confirm",f"Delete appointment {vals[0]}?",parent=self):
            self.appt_repo.delete(vals[0]); refresh()

    def confirm_appt():
        sel=tree.focus()
        if not sel: messagebox.showwarning("Select","Select an appointment.",parent=self); return
        aid=tree.item(sel,"values")[0]; appt=self.appt_repo.find_by_id(aid)
        if not appt: return
        self.appt_repo.update_status(aid,"Completed"); refresh()
        SMSDialog(self,appt["patient_name"],appt.get("patient_phone","N/A"),
                  appt["time"],appt["date"],appt["doctor_name"],"Completed")

    def cancel_appt():
        sel=tree.focus()
        if not sel: messagebox.showwarning("Select","Select an appointment.",parent=self); return
        aid=tree.item(sel,"values")[0]; appt=self.appt_repo.find_by_id(aid)
        if not appt: return
        if not messagebox.askyesno("Cancel",f"Cancel {aid}?",parent=self): return
        self.appt_repo.update_status(aid,"Cancelled"); refresh()
        SMSDialog(self,appt["patient_name"],appt.get("patient_phone","N/A"),
                  appt["time"],appt["date"],appt["doctor_name"],"Cancelled")

    RoundBtn(frm,"📅 Book Appointment",do_add,bg=color,fg=WHITE_FIXED).grid(row=6,column=0,pady=(10,0),sticky="w")
    bar=tk.Frame(page,bg=T["BG"]); bar.pack(fill="x",padx=24,pady=(4,2))
    RoundBtn(bar,"➕ Book",          do_add,       bg=color,  fg=WHITE_FIXED).pack(side="left",padx=2)
    RoundBtn(bar,"✏ Edit",           do_edit,      bg=AMBER,  fg=WHITE_FIXED).pack(side="left",padx=2)
    RoundBtn(bar,"🗑 Delete",         do_delete,    bg=RED,    fg=WHITE_FIXED).pack(side="left",padx=2)
    tk.Frame(bar,bg=T["BORDER"],width=2,height=30).pack(side="left",padx=8)
    RoundBtn(bar,"✅ Confirm + SMS",  confirm_appt, bg=GREEN,  fg=WHITE_FIXED).pack(side="left",padx=2)
    RoundBtn(bar,"❌ Cancel + SMS",   cancel_appt,  bg=RED,    fg=WHITE_FIXED).pack(side="left",padx=2)
    cols=["Appt ID","Patient","Doctor","Type","Date","Time","Reason","Status"]
    tree=self._tree(page,cols); refresh()


def _page_treatments(self):
    color = GREEN; T = self.T
    self._topbar("Treatment Records", f"Total: {len(self.treat_repo.get_all())} records")
    page = self._scrollable()
    frm  = self._form_card(page, "💊 Record New Treatment", color)
    pts  = self.pat_repo.get_all(); docs = self.doc_repo.get_all()
    pat_opts = [f"{p['patient_id']} — {p['name']}" for p in pts]
    doc_opts = [f"{d['doctor_id']} — {d['name']} ({d['specialization']})" for d in docs]
    fv = {k: tk.StringVar() for k in ["pat","doc","diag","med","lab","pharma","ward","notes","cost"]}
    self._lbl_combo(frm,"Patient *",0,0,fv["pat"],pat_opts,color,36)
    self._lbl_combo(frm,"Doctor *", 0,1,fv["doc"],doc_opts,color,36)
    self._lbl_entry(frm,"Diagnosis *",1,0,fv["diag"],color)
    self._lbl_entry(frm,"Medication",  1,1,fv["med"],color)
    self._lbl_entry(frm,"Lab Tests",   2,0,fv["lab"],color)
    tk.Label(frm,text="Pharmacy Items",font=F_SMALL,fg=T["TEXT2"],bg=T["CARD"]).grid(row=4,column=1,padx=(0,8),pady=(6,2),sticky="w")
    pharma_entry = tk.Entry(frm,textvariable=fv["pharma"],font=F_BODY,bg=T["INPUT_BG"],fg=T["TEXT"],
                            bd=0,highlightthickness=1,highlightbackground=T["BORDER"],
                            highlightcolor=color,insertbackground=color,width=18)
    pharma_entry.grid(row=5,column=1,padx=(0,4),pady=(0,4),sticky="ew")
    pharma_cost_v = tk.StringVar(value="0")

    def open_pharmacy():
        def on_confirm(total, items_str, cart):
            fv["pharma"].set(items_str); pharma_cost_v.set(str(total)); fv["cost"].set(str(total))
        PharmacySelectorDialog(self, on_confirm, T)

    RoundBtn(frm,"💊 Select Medicines",open_pharmacy,bg=PINK,fg=WHITE_FIXED).grid(row=6,column=1,pady=(4,0),sticky="w")
    self._lbl_entry(frm,"Ward / Room",         3,0,fv["ward"], color)
    self._lbl_entry(frm,"Notes",               3,1,fv["notes"],color)
    self._lbl_entry(frm,"Treatment Cost (LKR)",4,0,fv["cost"], color)

    def do_add():
        if not fv["pat"].get() or not fv["doc"].get() or not fv["diag"].get().strip():
            messagebox.showerror("Error","Patient, doctor and diagnosis required.",parent=self); return
        try: cost=float(fv["cost"].get() or "0")
        except: messagebox.showerror("Error","Invalid cost.",parent=self); return
        pid=fv["pat"].get().split(" — ")[0]; did=fv["doc"].get().split(" — ")[0]
        self.treat_repo.add({"patient_id":pid,"doctor_id":did,"diag":fv["diag"].get().strip(),
            "med":fv["med"].get().strip(),"lab":fv["lab"].get().strip(),
            "pharma":fv["pharma"].get().strip(),"ward":fv["ward"].get().strip(),
            "notes":fv["notes"].get().strip(),"cost":cost})
        for v in fv.values(): v.set("")
        refresh(); messagebox.showinfo("✅ Recorded","Treatment recorded!",parent=self)

    def refresh():
        self._fill(tree,[[t["treatment_id"],t["patient_name"],t["doctor_name"],t["diagnosis"],
            t["medication"] or "—",f"{t['treatment_cost']:,.2f}",t["date"]]
            for t in self.treat_repo.get_all()])

    def do_edit():
        sel=tree.focus()
        if not sel: messagebox.showwarning("Select","Select a treatment.",parent=self); return
        tid=tree.item(sel,"values")[0]; treat=self.treat_repo.find_by_id(tid)
        fields=[("diagnosis","Diagnosis","entry",None),("medication","Medication","entry",None),
                ("lab_tests","Lab Tests","entry",None),("pharmacy_items","Pharmacy Items","entry",None),
                ("ward","Ward / Room","entry",None),("notes","Notes","entry",None),
                ("treatment_cost","Treatment Cost","entry",None)]
        def save(d):
            try: cost=float(d["treatment_cost"] or "0")
            except: messagebox.showerror("Error","Invalid cost.",parent=self); return
            self.treat_repo.update(tid,{"diag":d["diagnosis"],"med":d["medication"],"lab":d["lab_tests"],
                "pharma":d["pharmacy_items"],"ward":d["ward"],"notes":d["notes"],"cost":cost}); refresh()
        EditDialog(self,f"Edit Treatment — {tid}",fields,treat,save,color,T)

    def do_delete():
        sel=tree.focus()
        if not sel: messagebox.showwarning("Select","Select a treatment.",parent=self); return
        vals=tree.item(sel,"values")
        if messagebox.askyesno("Confirm",f"Delete {vals[0]}? Linked bills deleted too.",parent=self):
            self.treat_repo.delete(vals[0]); refresh()

    RoundBtn(frm,"💊 Record Treatment",do_add,bg=color,fg=WHITE_FIXED).grid(row=10,column=0,pady=(10,0),sticky="w")
    self._crud_toolbar(page,do_add,do_edit,do_delete,color,"New Treatment")
    cols=["Treatment ID","Patient","Doctor","Diagnosis","Medication","Cost (LKR)","Date"]
    tree=self._tree(page,cols); refresh()


def _page_billing(self):
    color = PINK; T = self.T
    self._topbar("Billing & Payments", "Generate and manage patient bills")
    outer = tk.Frame(self.content, bg=T["BG"]); outer.pack(fill="both", expand=True)
    left = tk.Frame(outer, bg=T["CARD"], width=390); left.pack(side="left", fill="y"); left.pack_propagate(False)
    tk.Frame(left, bg=color, height=3).pack(fill="x")
    tk.Label(left, text=" 💰 Generate New Bill", font=F_SUB, fg=color, bg=T["CARD"]).pack(anchor="w", padx=16, pady=(10,4))
    tk.Frame(left, bg=T["BORDER"], height=1).pack(fill="x")
    bf = tk.Frame(left, bg=T["CARD"], padx=16, pady=12); bf.pack(fill="x")
    treats   = self.treat_repo.get_all()
    trt_opts = [f"{t['treatment_id']} — {t['patient_name']} ({t['diagnosis']})" for t in treats]
    fv = {k: tk.StringVar() for k in ["trt","consult","trt_cost","lab","pharma","ward"]}
    tk.Label(bf, text="Treatment Record *", font=F_SMALL, fg=T["TEXT2"], bg=T["CARD"]).pack(anchor="w", pady=(6,2))
    cb = ttk.Combobox(bf, textvariable=fv["trt"], values=trt_opts, font=F_BODY, state="readonly", width=38); cb.pack(fill="x", pady=(0,4))

    def on_trt(e=None):
        val=fv["trt"].get()
        if not val: return
        tid=val.split(" — ")[0]; trt=self.treat_repo.find_by_id(tid)
        if not trt: return
        doc=self.doc_repo.find_by_id(trt["doctor_id"])
        fv["consult"].set(str(doc["fee"]) if doc else "0"); fv["trt_cost"].set(str(trt["treatment_cost"]))
    cb.bind("<<ComboboxSelected>>", on_trt)

    for lbl,key in [("Consultation Fee (LKR)","consult"),("Treatment Cost (LKR)","trt_cost"),
                    ("Lab Fee (LKR)","lab"),("Pharmacy Cost (LKR)","pharma"),("Ward/Room Fee (LKR)","ward")]:
        tk.Label(bf,text=lbl,font=F_SMALL,fg=T["TEXT2"],bg=T["CARD"]).pack(anchor="w",pady=(6,2))
        tk.Entry(bf,textvariable=fv[key],font=F_BODY,bg=T["INPUT_BG"],fg=T["TEXT"],bd=0,
                 highlightthickness=1,highlightbackground=T["BORDER"],
                 highlightcolor=color,insertbackground=color,width=36).pack(fill="x",ipady=6,pady=(0,2))

    def do_generate():
        if not fv["trt"].get(): messagebox.showerror("Error","Select a treatment.",parent=self); return
        try:
            tid=fv["trt"].get().split(" — ")[0]; trt=self.treat_repo.find_by_id(tid)
            if not trt: messagebox.showerror("Error","Treatment not found.",parent=self); return
            cons=float(fv["consult"].get() or "0"); tc=float(fv["trt_cost"].get() or "0")
            lab=float(fv["lab"].get() or "0"); ph=float(fv["pharma"].get() or "0"); wd=float(fv["ward"].get() or "0")
        except ValueError: messagebox.showerror("Error","Enter valid numeric amounts.",parent=self); return
        bid=self.bill_repo.add({"patient_id":trt["patient_id"],"treatment_id":tid,"doctor_id":trt["doctor_id"],
            "consultation":cons,"treatment_cost":tc,"lab":lab,"pharma":ph,"ward":wd})
        for v in fv.values(): v.set("")
        refresh_bills(); messagebox.showinfo("✅ Generated",f"Bill {bid} generated!",parent=self)

    RoundBtn(bf,"🧾 Generate Bill",do_generate,bg=color,fg=WHITE_FIXED).pack(pady=(10,0))
    right = tk.Frame(outer, bg=T["BG"]); right.pack(side="left", fill="both", expand=True)
    tk.Label(right, text=" All Bills", font=F_SUB, fg=T["TEXT"], bg=T["BG"]).pack(anchor="w", padx=16, pady=(8,2))
    cols     = ["Bill ID","Patient","Total (LKR)","Status","Date"]
    bill_tbl = self._tree(right, cols, 6)

    def refresh_bills():
        self._fill(bill_tbl,[[b["bill_id"],b["patient_name"],f"{b['total']:,.2f}",b["status"],b["date"]]
                              for b in self.bill_repo.get_all()])
    refresh_bills()

    sel_v = tk.StringVar(); method_v = tk.StringVar(value="Cash")
    sel_row = tk.Frame(right, bg=T["BG"], padx=16, pady=4); sel_row.pack(fill="x")
    tk.Label(sel_row, text="Bill:", font=F_SMALL, fg=T["TEXT2"], bg=T["BG"]).pack(side="left")
    bill_ids = [b["bill_id"] for b in self.bill_repo.get_all()]
    id_cb = ttk.Combobox(sel_row, textvariable=sel_v, values=bill_ids, font=F_BODY, state="readonly", width=20); id_cb.pack(side="left", padx=6)
    tk.Label(sel_row, text="Method:", font=F_SMALL, fg=T["TEXT2"], bg=T["BG"]).pack(side="left")
    ttk.Combobox(sel_row, textvariable=method_v, values=["Cash","Card","Online Transfer","Insurance"],
                 font=F_BODY, state="readonly", width=16).pack(side="left", padx=6)

    rcpt = tk.Text(right, font=F_MONO, bg=T["CARD"], fg=T["TEXT"], bd=0, wrap="none", state="disabled", height=16)
    rcpt.pack(fill="both", expand=True, padx=16, pady=4)

    def show_receipt(e=None):
        bid=sel_v.get()
        if not bid: return
        id_cb["values"]=[b["bill_id"] for b in self.bill_repo.get_all()]
        b=self.bill_repo.find_by_id(bid)
        if not b: return
        paid=b["status"]=="Paid"
        sub=(b["consultation_fee"]+b["treatment_cost"]+b["lab_fee"]+b["pharmacy_cost"]+b["ward_fee"])
        text=f"""
╔═══════════════════════════════════════════════════════════╗
║         MEDI CARE HOSPITAL (PVT) LTD — RECEIPT           ║
╠═══════════════════════════════════════════════════════════╣
  Bill ID     : {b['bill_id']}
  Date        : {b['date']}
  Status      : {'✅ PAID' if paid else '❌ UNPAID'}
  Method      : {b['payment_method']}
───────────────────────────────────────────────────────────
  Patient     : {b['patient_name']}
  Doctor      : {b['doctor_name']}
  Diagnosis   : {b.get('diagnosis','—')}
───────────────────────────────────────────────────────────
  Consultation : LKR {b['consultation_fee']:>10,.2f}
  Treatment    : LKR {b['treatment_cost']:>10,.2f}
  Laboratory   : LKR {b['lab_fee']:>10,.2f}
  Pharmacy     : LKR {b['pharmacy_cost']:>10,.2f}
  Ward / Room  : LKR {b['ward_fee']:>10,.2f}
  Subtotal     : LKR {sub:>10,.2f}
  VAT (5%)     : LKR {b['tax']:>10,.2f}
  TOTAL DUE    : LKR {b['total']:>10,.2f}
╚═══════════════════════════════════════════════════════════╝
"""
        rcpt.config(state="normal"); rcpt.delete("1.0","end"); rcpt.insert("1.0",text)
        rcpt.config(state="disabled",fg=GREEN if paid else T["TEXT"])

    id_cb.bind("<<ComboboxSelected>>", show_receipt)
    if bill_ids: sel_v.set(bill_ids[0]); show_receipt()

    def mark_paid():
        bid=sel_v.get()
        if not bid: return
        self.bill_repo.mark_paid(bid,method_v.get()); refresh_bills(); show_receipt()
        messagebox.showinfo("✅ Paid",f"Bill {bid} marked as PAID.",parent=self)

    def delete_bill():
        bid=sel_v.get()
        if not bid: return
        if messagebox.askyesno("Confirm",f"Delete bill {bid}?",parent=self):
            self.bill_repo.delete(bid)
            new_ids=[b["bill_id"] for b in self.bill_repo.get_all()]
            id_cb["values"]=new_ids; sel_v.set(new_ids[0] if new_ids else "")
            refresh_bills()

    def export_pdf():
        bid=sel_v.get()
        if not bid: return
        b=self.bill_repo.find_by_id(bid)
        if not b: return
        fp=filedialog.asksaveasfilename(defaultextension=".pdf",filetypes=[("PDF files","*.pdf")],
                                        initialfile=f"Receipt_{bid}.pdf",parent=self)
        if not fp: return
        if export_bill_pdf(b,fp): messagebox.showinfo("✅ PDF Exported",f"Receipt saved:\n{fp}",parent=self)

    btn_r = tk.Frame(right, bg=T["BG"], padx=16, pady=4); btn_r.pack(fill="x")
    RoundBtn(btn_r,"✓ Mark Paid",   mark_paid,   bg=GREEN, fg=WHITE_FIXED).pack(side="left",padx=4)
    RoundBtn(btn_r,"📄 Export PDF", export_pdf,  bg=BRAND, fg=WHITE_FIXED).pack(side="left",padx=4)
    RoundBtn(btn_r,"🗑 Delete",      delete_bill, bg=RED,   fg=WHITE_FIXED).pack(side="left",padx=4)
    bill_tbl.bind("<<TreeviewSelect>>", lambda e: (sel_v.set(bill_tbl.item(bill_tbl.focus(),"values")[0]), show_receipt()) if bill_tbl.focus() and bill_tbl.item(bill_tbl.focus(),"values") else None)


def _page_reports(self):
    T = self.T
    self._topbar("Reports & Analytics", "Comprehensive system reports")
    nb = ttk.Notebook(self.content); nb.pack(fill="both", expand=True)
    pts   = self.pat_repo.get_all()
    docs  = self.doc_repo.get_all()
    bills = self.bill_repo.get_all()
    total = self.bill_repo.total_revenue()
    paid  = self.bill_repo.paid_revenue()
    out_c, in_c = self.pat_repo.count_by_type()

    t1 = tk.Frame(nb, bg=T["CARD"]); nb.add(t1, text=" 📊 Summary ")
    report = f"""
 ╔══════════════════════════════════════════════════════════════════════════╗
 ║          ✚ MEDI CARE HOSPITAL (PVT) LTD — SUMMARY REPORT               ║
 ║   Generated : {datetime.now().strftime('%A, %d %B %Y  %H:%M:%S')}
 ╠══════════════════════════════════════════════════════════════════════════╣
   👤  PATIENTS        Total: {len(pts)}  |  Out: {out_c}  |  In: {in_c}
   🩺  DOCTORS         Total: {len(docs)}  |  Specs: {len(self.doc_repo.by_spec())}
   📅  APPOINTMENTS    Total: {len(self.appt_repo.get_all())}  |  Today: {len(self.appt_repo.get_today())}
   💊  TREATMENTS      Total: {len(self.treat_repo.get_all())}
   💰  BILLING         Bills: {len(bills)}  |  Paid: {sum(1 for b in bills if b['status']=='Paid')}
       Total Revenue    : LKR {total:>15,.2f}
       Amount Collected : LKR {paid:>15,.2f}
       Outstanding      : LKR {total-paid:>15,.2f}
       Collection Rate  : {(paid/total*100 if total else 0):>14.1f}%
 ╚══════════════════════════════════════════════════════════════════════════╝
"""
    tw = tk.Text(t1, font=F_MONO, bg=T["CARD"], fg=T["TEXT"], bd=0, wrap="none")
    vsb = ttk.Scrollbar(t1, orient="vertical", command=tw.yview); tw.configure(yscrollcommand=vsb.set)
    tw.insert("1.0", report); tw.config(state="disabled")
    vsb.pack(side="right", fill="y"); tw.pack(fill="both", expand=True, padx=10, pady=10)

    tabs = [
        ("👤 Patients",
         ["Patient ID","Name","Age","Gender","Blood","Type","Phone","Registered"],
         [[p["patient_id"],p["name"],p["age"],p["gender"],p["blood_group"],
           p["patient_type"],p["phone"],p["created_at"]] for p in pts]),
        ("🩺 Doctors",
         ["Doctor ID","Name","Specialization","SLMC Reg","Phone","Fee (LKR)","Registered"],
         [[d["doctor_id"],d["name"],d["specialization"],d["reg_no"],
           d["phone"],f"{d['fee']:,.2f}",d["created_at"]] for d in docs]),
        ("📅 Appointments",
         ["Appt ID","Patient","Doctor","Type","Date","Time","Reason","Status"],
         [[a["appointment_id"],a["patient_name"],a["doctor_name"],
           a["appt_type"],a["date"],a["time"],a["reason"],a["status"]]
          for a in self.appt_repo.get_all()]),
        ("💰 Financial",
         ["Bill ID","Patient","Doctor","Total (LKR)","Method","Status","Date"],
         [[b["bill_id"],b["patient_name"],b["doctor_name"],
           f"{b['total']:,.2f}",b["payment_method"],b["status"],b["date"]]
          for b in bills]),
    ]
    for title, cols, rows in tabs:
        tf = tk.Frame(nb, bg=T["BG"]); nb.add(tf, text=f" {title} ")
        tbl = self._tree(tf, cols); self._fill(tbl, rows)


def _page_profile(self):
    T   = self.T
    uid = self.current_user["id"]
    is_admin  = self._is_admin()
    is_doctor = self._is_doctor()
    self._topbar("🩺 My Doctor Profile" if is_doctor else "⚙ Profile & Settings",
                 self.current_user["full_name"])
    page = self._scrollable()

    banner = tk.Canvas(page, height=120, bg="#0F172A", highlightthickness=0)
    banner.pack(fill="x", padx=24, pady=(12, 0))
    av_color = TEAL if is_doctor else BRAND
    banner.create_oval(16,16,96,96, fill=av_color, outline="#4A90D9", width=3)
    initials = "".join(w[0].upper() for w in self.current_user["full_name"].split()[:2])
    banner.create_text(56,56, text=initials, font=("Helvetica",24,"bold"), fill=WHITE_FIXED)
    banner.create_text(114,32, text=self.current_user["full_name"], font=("Helvetica",16,"bold"), fill=WHITE_FIXED, anchor="w")
    banner.create_text(114,56, text=f"@{self.current_user['username']}", font=("Helvetica",10), fill="#90B4D8", anchor="w")
    banner.create_text(114,80, text=self.current_user["role"], font=("Helvetica",9,"bold"), fill=av_color, anchor="w")

    tw_cols = tk.Frame(page, bg=T["BG"]); tw_cols.pack(fill="x", padx=24, pady=6)
    tw_cols.columnconfigure(0,weight=1); tw_cols.columnconfigure(1,weight=1)

    lo = tk.Frame(tw_cols, bg=T["CARD"]); lo.grid(row=0, column=0, padx=(0,8), sticky="nsew")
    tk.Frame(lo, bg=BRAND, height=3).pack(fill="x")
    tk.Label(lo, text=" 👤  Edit Account Info", font=F_SUB, fg=BRAND, bg=T["CARD"]).pack(anchor="w", pady=(10,4), padx=12)
    tk.Frame(lo, bg=T["BORDER"], height=1).pack(fill="x")
    lf = tk.Frame(lo, bg=T["CARD"], padx=18, pady=14); lf.pack(fill="x"); lf.columnconfigure(0,weight=1)
    cur = self.db.fetchone("SELECT * FROM users WHERE id=?", (uid,))
    fn_v = tk.StringVar(value=cur.get("full_name","") or "")
    un_v = tk.StringVar(value=cur.get("username","") or "")
    for i,(lbl,var) in enumerate([("Full Name",fn_v),("Username",un_v)]):
        tk.Label(lf,text=lbl,font=F_SMALL,fg=T["TEXT2"],bg=T["CARD"]).grid(row=i*2,column=0,sticky="w",pady=(8,2))
        tk.Entry(lf,textvariable=var,font=F_BODY,bg=T["INPUT_BG"],fg=T["TEXT"],bd=0,
                 highlightthickness=1,highlightbackground=T["BORDER"],
                 highlightcolor=BRAND,insertbackground=BRAND,width=32).grid(row=i*2+1,column=0,sticky="ew",pady=(0,4))
    msg1 = tk.Label(lf,text="",font=F_SMALL,bg=T["CARD"]); msg1.grid(row=4,column=0,sticky="w")

    def sp():
        nn=fn_v.get().strip(); nu=un_v.get().strip()
        if not nn or not nu: msg1.config(text="⚠ Required.",fg=RED); return
        self.db.exe("UPDATE users SET full_name=?,username=? WHERE id=?",(nn,nu,uid))
        self.current_user["full_name"]=nn; self.current_user["username"]=nu
        msg1.config(text="✅ Saved!",fg=GREEN)

    RoundBtn(lf,"💾 Save",sp,bg=BRAND,fg=WHITE_FIXED).grid(row=5,column=0,sticky="w",pady=(4,0))

    ro_f = tk.Frame(tw_cols, bg=T["CARD"]); ro_f.grid(row=0, column=1, padx=(8,0), sticky="nsew")
    tk.Frame(ro_f, bg=GREEN, height=3).pack(fill="x")
    tk.Label(ro_f, text=" 🔐  Change Password", font=F_SUB, fg=GREEN, bg=T["CARD"]).pack(anchor="w", pady=(10,4), padx=12)
    tk.Frame(ro_f, bg=T["BORDER"], height=1).pack(fill="x")
    rf = tk.Frame(ro_f, bg=T["CARD"], padx=18, pady=14); rf.pack(fill="x"); rf.columnconfigure(0,weight=1)
    cp_v=tk.StringVar(); np_v=tk.StringVar(); cf2_v=tk.StringVar()
    for i,(lbl,var) in enumerate([("Current Password",cp_v),("New Password",np_v),("Confirm New",cf2_v)]):
        tk.Label(rf,text=lbl,font=F_SMALL,fg=T["TEXT2"],bg=T["CARD"]).grid(row=i*2,column=0,sticky="w",pady=(8,2))
        tk.Entry(rf,textvariable=var,font=F_BODY,bg=T["INPUT_BG"],fg=T["TEXT"],bd=0,show="●",
                 highlightthickness=1,highlightbackground=T["BORDER"],
                 highlightcolor=GREEN,insertbackground=GREEN,width=32).grid(row=i*2+1,column=0,sticky="ew",pady=(0,4))
    msg2 = tk.Label(rf,text="",font=F_SMALL,bg=T["CARD"]); msg2.grid(row=6,column=0,sticky="w")

    def cpw():
        if not self.db.verify_login(self.current_user["username"],cp_v.get()):
            msg2.config(text="❌ Wrong current password.",fg=RED); return
        if len(np_v.get())<6: msg2.config(text="⚠ Min 6 chars.",fg=RED); return
        if np_v.get()!=cf2_v.get(): msg2.config(text="❌ Passwords don't match.",fg=RED); return
        self.db.exe("UPDATE users SET password=? WHERE id=?",
                    (hashlib.sha256(np_v.get().encode()).hexdigest(),uid))
        cp_v.set(""); np_v.set(""); cf2_v.set("")
        msg2.config(text="✅ Password changed!",fg=GREEN)

    RoundBtn(rf,"🔐 Change Password",cpw,bg=GREEN,fg=WHITE_FIXED).grid(row=7,column=0,sticky="w",pady=(4,0))

