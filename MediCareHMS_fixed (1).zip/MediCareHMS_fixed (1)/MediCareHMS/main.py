"""
╔══════════════════════════════════════════════════════════════════════════════╗
║       MEDI CARE HOSPITAL (PVT) LTD — HMS v7.0                               ║
║       MAIN ENTRY POINT — Run this file to start the application             ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Entry Point:
  - This file only creates the MediCareHMS instance.
  - All logic is in the class — this follows the "thin entry point" principle.
  - Clean Code: if __name__ == "__main__" guard ensures it won't run on import.

Login Credentials:
  Admin  → username: admin    password: admin123
  Doctor → username: doctor   password: doc123
"""

from gui.app import MediCareHMS

if __name__ == "__main__":
    app = MediCareHMS()
