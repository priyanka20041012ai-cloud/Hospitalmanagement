"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  database.py — DatabaseManager class (SQLite connection & operations)       ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts Used:
  - Encapsulation: All DB logic is hidden inside DatabaseManager.
    External code never touches sqlite3 directly.
  - Single Responsibility (SRP): This class only manages DB connection & queries.
  - Dependency Injection: Repositories receive this as a dependency (not create it).

Design Pattern:
  - Facade Pattern: DatabaseManager provides a simple interface (exe, fetch,
    fetchone) hiding complex SQLite details from the rest of the app.
"""

import sqlite3
import hashlib
import uuid
from datetime import datetime
from core.constants import DB_PATH


class DatabaseManager:
    """
    Manages all SQLite database connections and operations.

    Design Pattern → Facade:
      Wraps sqlite3 complexity into simple methods: exe(), fetch(), fetchone().
      Repositories only call these — they never write SQL connection logic.

    OOP → Encapsulation:
      _hash(), _create_tables(), _seed_default_user() are private (underscore).
      Only the public interface is exposed to the outside world.
    """

    def __init__(self, path=DB_PATH):
        self.path = path
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._create_tables()
        self._seed_default_user()

    def _create_tables(self):
        """Private: creates all tables on first run. Encapsulation."""
        self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL, full_name TEXT,
                role TEXT DEFAULT 'Staff', specialization TEXT,
                phone TEXT, email TEXT, created_at TEXT, theme TEXT DEFAULT 'light',
                doctor_id TEXT DEFAULT NULL
            );
            CREATE TABLE IF NOT EXISTS patients (
                patient_id TEXT PRIMARY KEY, name TEXT NOT NULL,
                age INTEGER, gender TEXT, phone TEXT, address TEXT,
                blood_group TEXT, patient_type TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS doctors (
                doctor_id TEXT PRIMARY KEY, name TEXT NOT NULL,
                age INTEGER, gender TEXT, phone TEXT, specialization TEXT,
                fee REAL, reg_no TEXT, created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS appointments (
                appointment_id TEXT PRIMARY KEY, patient_id TEXT, doctor_id TEXT,
                date TEXT, time TEXT, reason TEXT, appt_type TEXT,
                status TEXT DEFAULT 'Scheduled', created_at TEXT,
                FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
                FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
            );
            CREATE TABLE IF NOT EXISTS treatments (
                treatment_id TEXT PRIMARY KEY, patient_id TEXT, doctor_id TEXT,
                diagnosis TEXT, medication TEXT, lab_tests TEXT,
                pharmacy_items TEXT, ward TEXT, notes TEXT,
                treatment_cost REAL, date TEXT,
                FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
                FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
            );
            CREATE TABLE IF NOT EXISTS bills (
                bill_id TEXT PRIMARY KEY, patient_id TEXT, treatment_id TEXT,
                doctor_id TEXT, consultation_fee REAL, treatment_cost REAL,
                lab_fee REAL, pharmacy_cost REAL, ward_fee REAL,
                tax REAL, total REAL, payment_method TEXT DEFAULT 'Cash',
                status TEXT DEFAULT 'Unpaid', date TEXT,
                FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
                FOREIGN KEY (treatment_id) REFERENCES treatments(treatment_id),
                FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id)
            );
        """)
        self.conn.commit()
        # Safe column migration (add new column without breaking old DBs)
        try:
            self.conn.execute('ALTER TABLE users ADD COLUMN doctor_id TEXT DEFAULT NULL')
            self.conn.commit()
        except Exception:
            pass

    def _seed_default_user(self):
        """Private: seeds admin user only on first run."""
        if not self.conn.execute("SELECT 1 FROM users").fetchone():
            now = datetime.now().strftime("%Y-%m-%d %H:%M")
            self.conn.execute("INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (str(uuid.uuid4())[:8].upper(), "admin", self._hash("admin123"),
                 "Administrator", "Admin", None, "0112345678",
                 "admin@medicare.lk", now, "light", None))
            self.conn.commit()

    def _hash(self, pw):
        """Private: SHA-256 password hashing. Encapsulation."""
        return hashlib.sha256(pw.encode()).hexdigest()

    # ─── Public Facade Interface ──────────────────────────────────────────────

    def verify_login(self, u, p):
        """Verify credentials and return user dict or None."""
        r = self.conn.execute(
            "SELECT * FROM users WHERE username=? AND password=?",
            (u, self._hash(p))).fetchone()
        return dict(r) if r else None

    def exe(self, sql, p=()):
        """Execute INSERT / UPDATE / DELETE."""
        self.conn.execute(sql, p)
        self.conn.commit()

    def fetch(self, sql, p=()):
        """Execute SELECT and return list of dicts."""
        return [dict(r) for r in self.conn.execute(sql, p).fetchall()]

    def fetchone(self, sql, p=()):
        """Execute SELECT and return single dict or None."""
        r = self.conn.execute(sql, p).fetchone()
        return dict(r) if r else None

    def close(self):
        """Close connection gracefully."""
        self.conn.close()
