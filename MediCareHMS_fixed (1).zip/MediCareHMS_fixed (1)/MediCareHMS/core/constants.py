"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  constants.py — All global constants, themes, fonts, colors, medicine data ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP/Clean Code:
  - Single Responsibility Principle (SRP): This file only holds constants.
  - No logic, no classes — pure configuration/data.
  - Open/Closed Principle: Add new themes/medicines without touching other files.
"""

import os

# ─── Database path ────────────────────────────────────────────────────────────
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "medicare_v7.db")

# ─── Theme Definitions ────────────────────────────────────────────────────────
THEMES = {
    "light": {
        "BG":           "#F5F8FF",
        "WHITE":        "#FFFFFF",
        "SIDEBAR_BG":   "#1E3A5F",
        "SIDEBAR_ACT":  "#2A4F7C",
        "CARD":         "#FFFFFF",
        "CARD2":        "#F0F5FF",
        "TEXT":         "#0D1B2A",
        "TEXT2":        "#4A6080",
        "BORDER":       "#D0E0F5",
        "TREE_ROW":     "#F5F8FF",
        "TREE_ROW2":    "#FFFFFF",
        "INPUT_BG":     "#F0F5FF",
        "TOPBAR":       "#FFFFFF",
    },
    "dark": {
        "BG":           "#0F172A",
        "WHITE":        "#1E293B",
        "SIDEBAR_BG":   "#0B1120",
        "SIDEBAR_ACT":  "#1E3A5F",
        "CARD":         "#1E293B",
        "CARD2":        "#162032",
        "TEXT":         "#E2E8F0",
        "TEXT2":        "#94A3B8",
        "BORDER":       "#334155",
        "TREE_ROW":     "#1E293B",
        "TREE_ROW2":    "#253047",
        "INPUT_BG":     "#253047",
        "TOPBAR":       "#1E293B",
    }
}

# ─── Brand Colors ─────────────────────────────────────────────────────────────
BRAND       = "#1A6FD4"
BRAND_DARK  = "#1558B0"
BRAND_LIGHT = "#E8F1FD"
RED         = "#E53E3E"
GREEN       = "#2F9E44"
AMBER       = "#E67700"
PURPLE      = "#6741D9"
TEAL        = "#0C8599"
PINK        = "#C2255C"
WHITE_FIXED = "#FFFFFF"

# ─── Fonts ────────────────────────────────────────────────────────────────────
F_HUGE  = ("Helvetica", 28, "bold")
F_TITLE = ("Helvetica", 16, "bold")
F_HEAD  = ("Helvetica", 12, "bold")
F_SUB   = ("Helvetica", 10, "bold")
F_BODY  = ("Helvetica", 10)
F_SMALL = ("Helvetica", 9)
F_MONO  = ("Courier",   9)
F_NAV   = ("Helvetica", 10, "bold")
F_BTN   = ("Helvetica", 10, "bold")
F_GIANT = ("Helvetica", 42, "bold")

# ─── Medicine Catalog ─────────────────────────────────────────────────────────
MEDICINE_CATALOG = [
    {"name": "Paracetamol 500mg",       "unit": "Strip (10 tabs)", "price": 45.00,  "category": "Analgesic"},
    {"name": "Amoxicillin 500mg",        "unit": "Strip (10 caps)", "price": 120.00, "category": "Antibiotic"},
    {"name": "Amlodipine 5mg",           "unit": "Strip (30 tabs)", "price": 180.00, "category": "Cardiac"},
    {"name": "Metformin 500mg",          "unit": "Strip (30 tabs)", "price": 95.00,  "category": "Diabetic"},
    {"name": "Atorvastatin 20mg",        "unit": "Strip (10 tabs)", "price": 210.00, "category": "Cardiac"},
    {"name": "Omeprazole 20mg",          "unit": "Strip (10 caps)", "price": 85.00,  "category": "GI"},
    {"name": "Cetirizine 10mg",          "unit": "Strip (10 tabs)", "price": 55.00,  "category": "Antihistamine"},
    {"name": "Ibuprofen 400mg",          "unit": "Strip (10 tabs)", "price": 60.00,  "category": "Analgesic"},
    {"name": "Salbutamol Inhaler",       "unit": "1 Inhaler",       "price": 450.00, "category": "Respiratory"},
    {"name": "Vitamin C 500mg",          "unit": "Bottle (30 tabs)","price": 120.00, "category": "Supplement"},
    {"name": "Omega-3 Fish Oil",         "unit": "Bottle (60 caps)","price": 350.00, "category": "Supplement"},
    {"name": "Losartan 50mg",            "unit": "Strip (30 tabs)", "price": 165.00, "category": "Cardiac"},
    {"name": "Metronidazole 400mg",      "unit": "Strip (10 tabs)", "price": 75.00,  "category": "Antibiotic"},
    {"name": "Pantoprazole 40mg",        "unit": "Strip (10 tabs)", "price": 140.00, "category": "GI"},
    {"name": "Prednisolone 5mg",         "unit": "Strip (30 tabs)", "price": 90.00,  "category": "Steroid"},
    {"name": "Dextrose Saline (IV)",     "unit": "500ml Bag",       "price": 280.00, "category": "IV Fluid"},
    {"name": "Normal Saline (IV)",       "unit": "500ml Bag",       "price": 220.00, "category": "IV Fluid"},
    {"name": "Diclofenac Gel",           "unit": "30g Tube",        "price": 185.00, "category": "Topical"},
    {"name": "Ciprofloxacin 500mg",      "unit": "Strip (10 tabs)", "price": 155.00, "category": "Antibiotic"},
    {"name": "Folic Acid 5mg",           "unit": "Strip (30 tabs)", "price": 65.00,  "category": "Supplement"},
    {"name": "Atenolol 50mg",            "unit": "Strip (30 tabs)", "price": 130.00, "category": "Cardiac"},
    {"name": "Hydroxyzine 25mg",         "unit": "Strip (10 tabs)", "price": 95.00,  "category": "Antihistamine"},
    {"name": "Azithromycin 500mg",       "unit": "Strip (3 tabs)",  "price": 210.00, "category": "Antibiotic"},
    {"name": "Cough Syrup (Benadryl)",   "unit": "100ml Bottle",    "price": 180.00, "category": "Respiratory"},
    {"name": "Multivitamin Tablets",     "unit": "Bottle (30 tabs)","price": 250.00, "category": "Supplement"},
]
