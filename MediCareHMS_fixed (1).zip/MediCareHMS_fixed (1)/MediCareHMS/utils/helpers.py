"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  utils/helpers.py — Utility functions and reusable widgets                  ║
║  RoundBtn, _darker(), export_bill_pdf()                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts Used:
  - Inheritance: RoundBtn extends tk.Button — inherits all Button behaviour
    and adds hover effects on top. This is OOP Inheritance + Extension.
  - Encapsulation: _darker() is a private utility function.
  - Open/Closed Principle: RoundBtn adds hover without modifying tk.Button.

Clean Code:
  - Helper functions are small and do ONE thing.
  - export_bill_pdf() only deals with PDF generation — no UI logic.
"""

import tkinter as tk
from tkinter import messagebox
from core.constants import BRAND, WHITE_FIXED

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.platypus import (SimpleDocTemplate, Table as RLTable,
                                    TableStyle, Paragraph, Spacer, HRFlowable)
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    HAS_RL = True
except ImportError:
    HAS_RL = False


def _darker(c):
    """
    Return a slightly darker hex color string.
    Clean Code: small, pure function — no side effects.
    """
    try:
        r = max(0, int(c[1:3], 16) - 30)
        g = max(0, int(c[3:5], 16) - 30)
        b = max(0, int(c[5:7], 16) - 30)
        return f"#{r:02x}{g:02x}{b:02x}"
    except:
        return c


class RoundBtn(tk.Button):
    """
    Custom styled button with hover color effect.

    OOP → Inheritance:
      Extends tk.Button — inherits all button functionality.
      We only ADD hover behaviour on top. Parent class is NOT modified.

    SOLID → Open/Closed Principle:
      tk.Button is closed for modification, but RoundBtn extends it (open).

    Clean Code:
      Constructor clearly expresses purpose — bg, fg, hover are obvious.
    """

    def __init__(self, master, text, cmd, bg=BRAND, fg=WHITE_FIXED,
                 font=("Helvetica", 10, "bold"), **kw):
        super().__init__(master, text=text, command=cmd, bg=bg, fg=fg,
                         activebackground=_darker(bg), activeforeground=fg,
                         font=font, bd=0, relief="flat", cursor="hand2",
                         padx=14, pady=7, **kw)
        # Hover effect — bound events change color on mouse enter/leave
        self.bind("<Enter>", lambda e: self.config(bg=_darker(bg)))
        self.bind("<Leave>", lambda e: self.config(bg=bg))


def export_bill_pdf(bill: dict, filepath: str) -> bool:
    """
    Export a bill record as a formatted PDF receipt.

    Clean Code:
      - One function, one job: PDF generation only.
      - Returns bool so caller can show success/error message.
      - All styling is isolated here — GUI doesn't touch PDF logic.

    Design Pattern → Strategy (partial):
      Could swap this for an HTML or Excel exporter without changing callers.
    """
    if not HAS_RL:
        messagebox.showerror("Error", "ReportLab not installed. Run: pip install reportlab")
        return False

    doc    = SimpleDocTemplate(filepath, pagesize=A4,
                               rightMargin=2*cm, leftMargin=2*cm,
                               topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "title", parent=styles["Normal"], fontSize=18,
        fontName="Helvetica-Bold",
        textColor=colors.HexColor("#1E3A5F"),
        alignment=TA_CENTER, spaceAfter=4)
    sub_style = ParagraphStyle(
        "sub", parent=styles["Normal"], fontSize=10,
        textColor=colors.HexColor("#4A6080"),
        alignment=TA_CENTER, spaceAfter=2)

    paid = bill["status"] == "Paid"
    sub  = (bill["consultation_fee"] + bill["treatment_cost"] +
            bill["lab_fee"] + bill["pharmacy_cost"] + bill["ward_fee"])
    status_color = (colors.HexColor("#2F9E44") if paid else colors.HexColor("#E53E3E"))

    story = [
        Paragraph("✚  MEDI CARE HOSPITAL (PVT) LTD", title_style),
        Paragraph("Colombo, Sri Lanka  |  Tel: +94-11-2345678  |  medicare@hospital.lk", sub_style),
        HRFlowable(width="100%", thickness=2, color=colors.HexColor("#1A6FD4"), spaceAfter=12),
        Paragraph(f"OFFICIAL RECEIPT — {bill['bill_id']}",
                  ParagraphStyle("rh", parent=styles["Normal"], fontSize=13,
                                 fontName="Helvetica-Bold",
                                 textColor=colors.HexColor("#1A6FD4"),
                                 alignment=TA_CENTER, spaceAfter=8)),
    ]

    info = [
        ["Bill ID:",    bill["bill_id"],           "Date:",           bill["date"]],
        ["Patient:",    bill["patient_name"],       "Blood Group:",    bill.get("blood_group", "—")],
        ["Doctor:",     bill["doctor_name"],        "Specialization:", bill.get("specialization", "—")],
        ["Reg No:",     bill.get("reg_no", "—"),    "Diagnosis:",      bill.get("diagnosis", "—")],
        ["Medication:", bill.get("medication","—"), "Ward:",           bill.get("ward","—") or "—"],
        ["Payment:",    bill["payment_method"],     "Status:",         "✓ PAID" if paid else "✗ UNPAID"],
    ]
    info_tbl = RLTable(info, colWidths=[3.5*cm, 6.5*cm, 3.5*cm, 6.5*cm])
    info_tbl.setStyle(TableStyle([
        ("FONTNAME",  (0,0),(-1,-1), "Helvetica"),
        ("FONTSIZE",  (0,0),(-1,-1), 9),
        ("FONTNAME",  (0,0),(0,-1),  "Helvetica-Bold"),
        ("FONTNAME",  (2,0),(2,-1),  "Helvetica-Bold"),
        ("TEXTCOLOR", (0,0),(0,-1),  colors.HexColor("#1E3A5F")),
        ("TEXTCOLOR", (2,0),(2,-1),  colors.HexColor("#1E3A5F")),
        ("TEXTCOLOR", (3,5),(3,5),   status_color),
        ("ROWBACKGROUNDS",(0,0),(-1,-1), [colors.HexColor("#F5F8FF"), colors.white]),
        ("GRID",      (0,0),(-1,-1), 0.5, colors.HexColor("#D0E0F5")),
        ("TOPPADDING",(0,0),(-1,-1), 6),
        ("BOTTOMPADDING",(0,0),(-1,-1),6),
        ("LEFTPADDING",(0,0),(-1,-1), 8),
    ]))
    story.append(info_tbl)
    story.append(Spacer(1, 16))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#D0E0F5"), spaceAfter=8))

    charges = [
        ["ITEM",              "AMOUNT (LKR)"],
        ["Consultation Fee",  f"{bill['consultation_fee']:,.2f}"],
        ["Treatment Cost",    f"{bill['treatment_cost']:,.2f}"],
        ["Laboratory Fee",    f"{bill['lab_fee']:,.2f}"],
        ["Pharmacy Cost",     f"{bill['pharmacy_cost']:,.2f}"],
        ["Ward / Room Fee",   f"{bill['ward_fee']:,.2f}"],
        ["Subtotal",          f"{sub:,.2f}"],
        ["VAT (5%)",          f"{bill['tax']:,.2f}"],
        ["TOTAL DUE",         f"{bill['total']:,.2f}"],
    ]
    ch_tbl = RLTable(charges, colWidths=[12*cm, 5.5*cm])
    ch_tbl.setStyle(TableStyle([
        ("BACKGROUND",  (0,0),(-1,0),  colors.HexColor("#1E3A5F")),
        ("TEXTCOLOR",   (0,0),(-1,0),  colors.white),
        ("FONTNAME",    (0,0),(-1,0),  "Helvetica-Bold"),
        ("FONTSIZE",    (0,0),(-1,0),  10),
        ("FONTNAME",    (0,1),(-1,-1), "Helvetica"),
        ("FONTSIZE",    (0,1),(-1,-1), 10),
        ("ALIGN",       (1,0),(1,-1),  "RIGHT"),
        ("ROWBACKGROUNDS",(0,1),(-1,-3), [colors.HexColor("#F5F8FF"), colors.white]),
        ("BACKGROUND",  (0,-3),(-1,-3), colors.HexColor("#E8F1FD")),
        ("FONTNAME",    (0,-3),(-1,-3), "Helvetica-Bold"),
        ("BACKGROUND",  (0,-2),(-1,-2), colors.HexColor("#FFF9DB")),
        ("BACKGROUND",  (0,-1),(-1,-1), colors.HexColor("#1A6FD4")),
        ("TEXTCOLOR",   (0,-1),(-1,-1), colors.white),
        ("FONTNAME",    (0,-1),(-1,-1), "Helvetica-Bold"),
        ("FONTSIZE",    (0,-1),(-1,-1), 12),
        ("GRID",        (0,0),(-1,-1),  0.5, colors.HexColor("#D0E0F5")),
        ("TOPPADDING",  (0,0),(-1,-1),  7),
        ("BOTTOMPADDING",(0,0),(-1,-1), 7),
        ("LEFTPADDING", (0,0),(-1,-1),  10),
        ("RIGHTPADDING",(0,0),(-1,-1),  10),
    ]))
    story.append(ch_tbl)
    story.append(Spacer(1, 24))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#D0E0F5"), spaceAfter=8))
    story.append(Paragraph(
        "Thank you for choosing Medi Care Hospital (PVT) Ltd.",
        ParagraphStyle("thanks", parent=styles["Normal"], fontSize=10,
                        fontName="Helvetica-Bold",
                        textColor=colors.HexColor("#2F9E44"),
                        alignment=TA_CENTER)))
    story.append(Paragraph(
        "This is a computer-generated receipt and requires no signature.",
        ParagraphStyle("note", parent=styles["Normal"], fontSize=8,
                        textColor=colors.HexColor("#94A3B8"),
                        alignment=TA_CENTER)))
    doc.build(story)
    return True
