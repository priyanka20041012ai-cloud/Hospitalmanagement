"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  services/report_service.py — ReportService (business logic layer)          ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts:
  - Encapsulation: All report assembly logic is inside this class.
    The GUI just calls generate_summary() and gets a ReportData object.
  - SRP: Only report generation. No UI, no DB calls directly.
  - Dependency Injection: All 5 repositories passed via constructor.

Design Pattern:
  - Facade Pattern: ReportService.generate_summary() is a facade —
    one call that hides coordinating 5 different repositories.
  - Builder Pattern: delegates to ReportData.build() to assemble
    the complete report object from all sources.

SOLID:
  - D (DIP): Depends on repository abstractions, not sqlite3.
  - S (SRP): Only report logic here.
"""

from models.report import ReportData
from repositories.repositories import (
    PatientRepository, DoctorRepository,
    AppointmentRepository, TreatmentRepository, BillRepository
)


class ReportService:
    """
    Service Layer for Report generation.

    OOP → Encapsulation: Hides the complexity of assembling
    data from 5 different repositories into one clean report.

    Design Pattern → Facade:
      gui.py calls report_service.generate_summary() — one method.
      Internally it coordinates 5 repos. GUI doesn't see any of that.

    SOLID → DIP: All dependencies are injected via constructor.
    """

    def __init__(self,
                 pat_repo:   PatientRepository,
                 doc_repo:   DoctorRepository,
                 appt_repo:  AppointmentRepository,
                 treat_repo: TreatmentRepository,
                 bill_repo:  BillRepository):
        # Dependency Injection — all repos passed in
        self._pat   = pat_repo
        self._doc   = doc_repo
        self._appt  = appt_repo
        self._treat = treat_repo
        self._bill  = bill_repo

    def generate_summary(self) -> ReportData:
        """
        Generate a complete HMS summary report.

        Facade: one call replaces 10+ individual repo calls.
        Builder: delegates to ReportData.build() for assembly.
        Returns a clean ReportData model object.
        """
        return ReportData.build(
            pat_repo   = self._pat,
            doc_repo   = self._doc,
            appt_repo  = self._appt,
            treat_repo = self._treat,
            bill_repo  = self._bill,
        )

    def get_patient_report(self) -> list:
        """Returns all patient records for the patient report tab."""
        return self._pat.get_all()

    def get_doctor_report(self) -> list:
        """Returns all doctor records for the doctor report tab."""
        return self._doc.get_all()

    def get_appointment_report(self) -> list:
        """Returns all appointment records for the appointment report tab."""
        return self._appt.get_all()

    def get_financial_report(self) -> list:
        """Returns all bill records for the financial report tab."""
        return self._bill.get_all()

    def get_treatment_report(self) -> list:
        """Returns all treatment records for the treatment report tab."""
        return self._treat.get_all()

    def get_revenue_breakdown(self) -> dict:
        """
        Returns a revenue breakdown dict for quick dashboard display.
        Clean Code: meaningful name, clear return structure.
        """
        total = self._bill.total_revenue()
        paid  = self._bill.paid_revenue()
        return {
            "total":       total,
            "paid":        paid,
            "outstanding": round(total - paid, 2),
            "rate":        round((paid / total * 100) if total else 0, 1),
            "monthly":     self._bill.monthly_revenue(),
        }

    def get_doctor_performance(self) -> list:
        """
        Returns a list of doctors with their appointment and treatment counts.
        Used for the Reports → Doctor Performance tab.

        OOP → Business logic here, not in the GUI.
        """
        doctors  = self._doc.get_all()
        result   = []
        for doc in doctors:
            did    = doc["doctor_id"]
            appts  = self._appt.get_for_doctor(did)
            treats = self._treat.get_for_doctor(did)
            completed = sum(1 for a in appts if a["status"] == "Completed")
            revenue   = sum(t.get("treatment_cost", 0) or 0 for t in treats)
            result.append({
                "doctor_id":      did,
                "name":           doc["name"],
                "specialization": doc["specialization"],
                "total_appts":    len(appts),
                "completed":      completed,
                "treatments":     len(treats),
                "revenue":        revenue,
            })
        # Sort by revenue descending — most productive doctors first
        result.sort(key=lambda x: x["revenue"], reverse=True)
        return result
