"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  services/treatment_service.py — TreatmentService (business logic layer)    ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts:
  - Encapsulation: Treatment cost validation, pharmacy item processing,
    and lab test formatting are all inside this class.
  - SRP: Only treatment business rules. No billing, no patient management.
  - Dependency Injection: Receives TreatmentRepository via constructor.

Design Pattern → Service Layer:
  GUI → TreatmentService → TreatmentRepository → DB.
  The service is the single source of truth for treatment rules.
"""

from repositories.repositories import TreatmentRepository
from models.treatment import Treatment


class TreatmentService:
    """
    Service Layer for Treatment operations.

    OOP → Encapsulation: Treatment rules (cost must be ≥ 0,
    diagnosis must not be empty) are enforced here, not in the GUI.

    Design Pattern → Service Layer: All treatment business logic
    is centralised. GUI and Doctor pages both call this service.
    """

    def __init__(self, treat_repo: TreatmentRepository):
        self._repo = treat_repo  # Dependency Injection

    def record_treatment(self, patient_id: str, doctor_id: str,
                          diagnosis: str, medication: str = "",
                          lab_tests: str = "", pharmacy_items: str = "",
                          ward: str = "", notes: str = "",
                          cost: float = 0.0) -> str:
        """
        Record a new treatment with validation.
        Returns treatment_id on success. Raises ValueError on bad input.
        """
        diagnosis = diagnosis.strip()
        if not diagnosis:
            raise ValueError("Diagnosis is required.")
        if not patient_id:
            raise ValueError("Patient must be selected.")
        if not doctor_id:
            raise ValueError("Doctor must be selected.")
        if cost < 0:
            raise ValueError("Treatment cost cannot be negative.")

        return self._repo.add({
            "patient_id": patient_id,
            "doctor_id":  doctor_id,
            "diag":       diagnosis,
            "med":        medication.strip(),
            "lab":        lab_tests.strip(),
            "pharma":     pharmacy_items.strip(),
            "ward":       ward.strip(),
            "notes":      notes.strip(),
            "cost":       cost,
        })

    def update_treatment(self, treatment_id: str, diagnosis: str,
                          medication: str, lab_tests: str,
                          pharmacy_items: str, ward: str,
                          notes: str, cost: float):
        """Update a treatment record with validation."""
        diagnosis = diagnosis.strip()
        if not diagnosis:
            raise ValueError("Diagnosis is required.")
        if cost < 0:
            raise ValueError("Treatment cost cannot be negative.")

        self._repo.update(treatment_id, {
            "diag":   diagnosis,
            "med":    medication.strip(),
            "lab":    lab_tests.strip(),
            "pharma": pharmacy_items.strip(),
            "ward":   ward.strip(),
            "notes":  notes.strip(),
            "cost":   cost,
        })

    def delete_treatment(self, treatment_id: str):
        """
        Delete a treatment and its linked bills.
        The repository handles cascading deletion.
        """
        self._repo.delete(treatment_id)

    def get_all(self):
        """Return all treatment records with patient and doctor names."""
        return self._repo.get_all()

    def find_by_id(self, treatment_id: str):
        """Find a specific treatment record."""
        return self._repo.find_by_id(treatment_id)

    def get_for_doctor(self, doctor_id: str):
        """Get all treatments handled by a specific doctor."""
        return self._repo.get_for_doctor(doctor_id)

    def get_statistics(self, doctor_id: str = None) -> dict:
        """
        Returns treatment statistics.
        If doctor_id given — stats for that doctor only.
        Otherwise — system-wide stats.

        OOP → Polymorphic-style behaviour based on argument presence.
        """
        treats = (self._repo.get_for_doctor(doctor_id)
                  if doctor_id else self._repo.get_all())
        total_cost = sum(t.get("treatment_cost", 0) or 0 for t in treats)
        unique_patients = len(set(t["patient_id"] for t in treats))
        avg_cost = round(total_cost / len(treats), 2) if treats else 0.0

        return {
            "total":           len(treats),
            "total_cost":      total_cost,
            "unique_patients": unique_patients,
            "avg_cost":        avg_cost,
        }

    def get_as_models(self, doctor_id: str = None):
        """
        Returns list of Treatment model objects (not raw dicts).
        Uses the Treatment dataclass — proper OOP return type.
        """
        rows = (self._repo.get_for_doctor(doctor_id)
                if doctor_id else self._repo.get_all())
        return [Treatment.from_dict(r) for r in rows]
