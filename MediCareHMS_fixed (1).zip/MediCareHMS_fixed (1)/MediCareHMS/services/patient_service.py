"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  services/patient_service.py — PatientService (business logic layer)        ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts:
  - Encapsulation: Validation logic (age check, name check) is inside this
    class — the GUI never duplicates validation rules.
  - SRP: Only handles patient business rules. No UI, no raw SQL.
  - Dependency Injection: PatientRepository passed via constructor.

SOLID:
  - D (DIP): Depends on PatientRepository abstraction, not sqlite3.
  - S (SRP): Patient registration, search, update — nothing else.

Design Pattern:
  - Service Layer: GUI → PatientService → PatientRepository → DB.
    The GUI calls register_patient() and trusts the service to validate.
"""

from repositories.repositories import PatientRepository
from models.patient import Patient



class PatientService:
    """
    Service Layer for Patient operations.

    Handles all patient business rules:
      - Validation before add/update
      - Search logic
      - Statistics

    OOP → Encapsulation: Validation rules live here, not in GUI.
    Design Pattern → Service Layer: One place for all patient business logic.
    """

    def __init__(self, pat_repo: PatientRepository):
        self._repo = pat_repo  # Dependency Injection

    def register_patient(self, name: str, age: int, gender: str,
                          phone: str, address: str, blood: str,
                          ptype: str) -> str:
        """
        Register a new patient with validation.
        Returns patient_id on success.
        Raises ValueError on invalid input.

        Clean Code: raises exceptions with clear messages
        instead of returning error strings.
        """
        name = name.strip()
        if not name:
            raise ValueError("Patient name is required.")
        if not (0 < age < 130):
            raise ValueError("Age must be between 1 and 129.")

        return self._repo.add({
            "name":    name,
            "age":     age,
            "gender":  gender,
            "phone":   phone.strip(),
            "address": address.strip(),
            "blood":   blood,
            "ptype":   ptype,
        })

    def update_patient(self, patient_id: str, name: str, age: int,
                        gender: str, phone: str, address: str,
                        blood: str, ptype: str):
        """Update patient record with validation."""
        name = name.strip()
        if not name:
            raise ValueError("Patient name is required.")
        if not (0 < age < 130):
            raise ValueError("Age must be between 1 and 129.")

        self._repo.update(patient_id, {
            "name":    name,
            "age":     age,
            "gender":  gender,
            "phone":   phone.strip(),
            "address": address.strip(),
            "blood":   blood,
            "ptype":   ptype,
        })

    def delete_patient(self, patient_id: str):
        """Delete a patient record."""
        self._repo.delete(patient_id)

    def get_all(self):
        """Return all patients."""
        return self._repo.get_all()

    def find_by_id(self, patient_id: str):
        """Find a specific patient by ID."""
        return self._repo.find_by_id(patient_id)

    def search(self, query: str):
        """Search patients by name, ID, phone, or blood group."""
        query = query.strip()
        if not query:
            return self._repo.get_all()
        return self._repo.search(query)

    def get_statistics(self) -> dict:
        """
        Returns a summary statistics dict for the dashboard.
        Clean Code: named method instead of calling two repo methods in GUI.
        """
        out_c, in_c = self._repo.count_by_type()
        total = len(self._repo.get_all())
        return {
            "total":       total,
            "outpatients": out_c,
            "inpatients":  in_c,
        }

    def get_patients_for_doctor(self, doctor_id: str):
        """Get all patients linked to a specific doctor."""
        return self._repo.get_for_doctor(doctor_id)
