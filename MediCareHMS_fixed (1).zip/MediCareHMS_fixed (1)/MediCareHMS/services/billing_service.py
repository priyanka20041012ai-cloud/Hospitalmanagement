"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  services/billing_service.py — BillingService (business logic layer)       ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts Used:
  - Encapsulation: All billing calculation logic is inside this class.
  - SRP: This class only handles billing business rules (tax, total calculation).
  - Dependency Injection: Receives repositories via constructor — doesn't create them.

Design Pattern:
  - Service Layer Pattern: Separates business logic from UI (GUI) and data (Repository).
    GUI calls Service → Service calls Repository → Repository calls DB.
    This is the classic 3-layer architecture (Presentation → Business → Data).

SOLID:
  - D (DIP): BillingService depends on IRepository abstraction, not concrete classes.
  - S (SRP): Only billing logic here — not patient or doctor logic.
"""

from repositories.repositories import BillRepository, TreatmentRepository, DoctorRepository


class BillingService:
    """
    Service Layer for Billing operations.

    Design Pattern → Service Layer:
      GUI never calculates tax or totals directly.
      It calls BillingService.generate_bill() which handles the rules.

    OOP → Dependency Injection:
      Repositories injected via __init__ — not created inside the class.
      This makes the service testable and flexible.
    """

    TAX_RATE = 0.05  # 5% VAT — single place to change

    def __init__(self, bill_repo: BillRepository,
                 treat_repo: TreatmentRepository,
                 doc_repo: DoctorRepository):
        self._bill_repo  = bill_repo
        self._treat_repo = treat_repo
        self._doc_repo   = doc_repo

    def calculate_total(self, consultation: float, treatment_cost: float,
                         lab: float, pharma: float, ward: float) -> dict:
        """
        Pure business logic: calculate subtotal, tax, and grand total.
        Returns a dict with breakdown — no DB calls here.
        Clean Code: one function, one responsibility.
        """
        subtotal = consultation + treatment_cost + lab + pharma + ward
        tax      = round(subtotal * self.TAX_RATE, 2)
        total    = round(subtotal + tax, 2)
        return {
            "subtotal": subtotal,
            "tax":      tax,
            "total":    total,
        }

    def generate_bill(self, treatment_id: str, lab: float = 0.0,
                      pharma: float = 0.0, ward: float = 0.0) -> str:
        """
        Service method: auto-fetch consultation fee from doctor,
        treatment cost from treatment, then create a bill.
        Returns the new bill_id.
        """
        trt = self._treat_repo.find_by_id(treatment_id)
        if not trt:
            raise ValueError(f"Treatment {treatment_id} not found.")
        doc = self._doc_repo.find_by_id(trt["doctor_id"])
        consultation = doc["fee"] if doc else 0.0
        return self._bill_repo.add({
            "patient_id":     trt["patient_id"],
            "treatment_id":   treatment_id,
            "doctor_id":      trt["doctor_id"],
            "consultation":   consultation,
            "treatment_cost": trt["treatment_cost"],
            "lab":            lab,
            "pharma":         pharma,
            "ward":           ward,
        })

    def mark_paid(self, bill_id: str, method: str = "Cash"):
        """Mark a bill as paid with given payment method."""
        self._bill_repo.mark_paid(bill_id, method)

    def get_revenue_summary(self) -> dict:
        """Returns a dict with total, paid, and outstanding revenue."""
        total = self._bill_repo.total_revenue()
        paid  = self._bill_repo.paid_revenue()
        return {
            "total":       total,
            "paid":        paid,
            "outstanding": round(total - paid, 2),
            "rate":        round((paid / total * 100) if total else 0, 1),
        }
