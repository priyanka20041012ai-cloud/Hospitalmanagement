import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from core.constants import (BRAND, GREEN, RED, AMBER, PURPLE, TEAL, PINK,
                             WHITE_FIXED, F_HEAD, F_SUB, F_BODY, F_SMALL,
                             F_BTN, MEDICINE_CATALOG)
from utils.helpers import RoundBtn


# ═══════════════════════════════════════════════════════════════════════
# SMS NOTIFICATION DIALOG
# ═══════════════════════════════════════════════════════════════════════

class SMSDialog(tk.Toplevel):
    """
    Simulates an SMS notification after appointment status change.

    OOP → Inheritance: Extends tk.Toplevel — reuses all window behaviour.
    OOP → Encapsulation: SMS message building logic is inside _build().
    """

    def __init__(self, master, patient_name, phone, appt_time,
                 appt_date, doctor_name, status):
        super().__init__(master)
        self.title("📱 SMS Notification")
        w, h = 480, 400
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        self.resizable(False, False)
        self.configure(bg="#0F172A")
        self.grab_set()
        self._build(patient_name, phone, appt_time, appt_date, doctor_name, status)

    def _build(self, patient_name, phone, appt_time, appt_date, doctor_name, status):
        hdr = tk.Frame(self, bg="#1E293B", padx=20, pady=14)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📱  SMS Notification Sent",
                 font=("Helvetica", 13, "bold"), fg=GREEN, bg="#1E293B").pack(anchor="w")
        tk.Label(hdr, text=f"To: {patient_name}  |  {phone}",
                 font=("Helvetica", 9), fg="#94A3B8", bg="#1E293B").pack(anchor="w")

        phone_frame = tk.Frame(self, bg="#0F172A", pady=10)
        phone_frame.pack(fill="both", expand=True, padx=20, pady=10)
        shell = tk.Frame(phone_frame, bg="#1E293B", bd=2, relief="solid")
        shell.pack(expand=True, pady=4)

        top_bar = tk.Frame(shell, bg="#334155", height=30)
        top_bar.pack(fill="x")
        tk.Label(top_bar, text=f"📶  {phone}", font=("Helvetica", 8),
                 fg="#94A3B8", bg="#334155").pack(side="left", padx=10, pady=6)
        tk.Label(top_bar, text=datetime.now().strftime("%H:%M"),
                 font=("Helvetica", 8, "bold"), fg=WHITE_FIXED,
                 bg="#334155").pack(side="right", padx=10)

        bubble_area = tk.Frame(shell, bg="#0F172A", padx=12, pady=12)
        bubble_area.pack(fill="both", expand=True)
        sender_row = tk.Frame(bubble_area, bg="#0F172A")
        sender_row.pack(fill="x", pady=(0, 6))
        tk.Label(sender_row, text="MEDICARE-HOSP", font=("Helvetica", 7, "bold"),
                 fg="#94A3B8", bg="#0F172A").pack(anchor="w")

        if status == "Completed":
            icon = "✅"; color = GREEN
            msg = (f"{icon} Dear {patient_name},\n\nYour appointment with {doctor_name}"
                   f" on {appt_date} at {appt_time} has been CONFIRMED.\n\n"
                   f"Please arrive 15 minutes early.\n"
                   f"For queries: +94-11-2345678\n\n- Medi Care Hospital")
        else:
            icon = "❌"; color = RED
            msg = (f"{icon} Dear {patient_name},\n\nYour appointment with {doctor_name}"
                   f" on {appt_date} at {appt_time} has been CANCELLED.\n\n"
                   f"To reschedule: +94-11-2345678\n"
                   f"We apologize for the inconvenience.\n\n- Medi Care Hospital")

        bubble = tk.Frame(bubble_area, bg="#1A3A5C", padx=14, pady=10)
        bubble.pack(fill="x")
        tk.Label(bubble, text=msg, font=("Helvetica", 9), fg=WHITE_FIXED,
                 bg="#1A3A5C", justify="left", wraplength=340).pack(anchor="w")
        tick = tk.Frame(bubble_area, bg="#0F172A")
        tick.pack(fill="x")
        tk.Label(tick, text=f"✓✓ Delivered • {datetime.now().strftime('%H:%M')}",
                 font=("Helvetica", 7), fg="#64748B", bg="#0F172A").pack(side="right")

        badge_f = tk.Frame(self, bg="#0F172A", pady=4)
        badge_f.pack(fill="x", padx=20)
        tk.Frame(badge_f, bg=color, height=3).pack(fill="x", pady=(0, 6))
        tk.Label(badge_f, text=f"SMS notification sent to {patient_name} ({phone})",
                 font=("Helvetica", 9, "bold"), fg=color, bg="#0F172A").pack()

        btn_f = tk.Frame(self, bg="#0F172A", pady=10)
        btn_f.pack(fill="x", padx=20)
        RoundBtn(btn_f, "✓ Close", self.destroy, bg=color, fg=WHITE_FIXED).pack()


# ═══════════════════════════════════════════════════════════════════════
# PHARMACY MEDICINE SELECTOR DIALOG
# ═══════════════════════════════════════════════════════════════════════

class PharmacySelectorDialog(tk.Toplevel):
    """
    Dialog to select medicines from catalog and add to cart.

    OOP → Encapsulation: self.cart is private state — parent can't touch it.
    Design Pattern → Observer: on_confirm callback notifies parent of result.
    OOP → Inheritance: extends tk.Toplevel.
    """

    def __init__(self, master, on_confirm, th=None):
        super().__init__(master)
        self.title("💊 Pharmacy — Select Medicines")
        w, h = 820, 620
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        self.resizable(True, True)
        T = th or {"WHITE": "#FFFFFF", "BG": "#F5F8FF", "TEXT": "#0D1B2A",
                   "TEXT2": "#4A6080", "BORDER": "#D0E0F5", "CARD": "#FFFFFF",
                   "CARD2": "#F0F5FF", "INPUT_BG": "#F0F5FF"}
        self.T = T
        self.configure(bg=T["BG"])
        self.grab_set()
        self.on_confirm = on_confirm  # Callback — Observer pattern
        self.cart = {}                # Encapsulated state
        self._build()

    def _build(self):
        T = self.T
        tk.Frame(self, bg=GREEN, height=4).pack(fill="x")
        hdr = tk.Frame(self, bg=T["CARD"], padx=20, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="💊  Pharmacy Medicine Selector",
                 font=F_HEAD, fg=GREEN, bg=T["CARD"]).pack(side="left")
        self.total_lbl = tk.Label(hdr, text="Total: LKR 0.00",
                                  font=("Helvetica", 11, "bold"),
                                  fg=BRAND, bg=T["CARD"])
        self.total_lbl.pack(side="right", padx=10)
        tk.Frame(self, bg=T["BORDER"], height=1).pack(fill="x")

        sf = tk.Frame(self, bg=T["BG"], padx=16, pady=8)
        sf.pack(fill="x")
        tk.Label(sf, text="🔍 Search:", font=F_SMALL, fg=T["TEXT2"], bg=T["BG"]).pack(side="left")
        self.search_v = tk.StringVar()
        se = tk.Entry(sf, textvariable=self.search_v, font=F_BODY, bg=T["CARD"],
                      fg=T["TEXT"], bd=0, highlightthickness=1,
                      highlightbackground=T["BORDER"], highlightcolor=GREEN,
                      insertbackground=GREEN, width=30)
        se.pack(side="left", padx=8, ipady=6)
        self.search_v.trace("w", lambda *_: self._refresh_catalog())

        tk.Label(sf, text="Category:", font=F_SMALL, fg=T["TEXT2"], bg=T["BG"]).pack(side="left", padx=(10, 4))
        cats = ["All"] + sorted(set(m["category"] for m in MEDICINE_CATALOG))
        self.cat_v = tk.StringVar(value="All")
        cat_cb = ttk.Combobox(sf, textvariable=self.cat_v, values=cats,
                               font=F_BODY, state="readonly", width=16)
        cat_cb.pack(side="left")
        cat_cb.bind("<<ComboboxSelected>>", lambda e: self._refresh_catalog())

        main = tk.Frame(self, bg=T["BG"])
        main.pack(fill="both", expand=True, padx=16, pady=4)
        main.columnconfigure(0, weight=3); main.columnconfigure(1, weight=2)

        left = tk.Frame(main, bg=T["CARD"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        tk.Frame(left, bg=TEAL, height=3).pack(fill="x")
        tk.Label(left, text=" 🏥 Medicine Catalog", font=F_SUB,
                 fg=TEAL, bg=T["CARD"]).pack(anchor="w", padx=8, pady=4)
        tk.Frame(left, bg=T["BORDER"], height=1).pack(fill="x")

        cat_cols = ["Medicine", "Unit", "Price (LKR)", "Category"]
        self.cat_tree = ttk.Treeview(left, columns=cat_cols, show="headings", height=16)
        for col in cat_cols:
            self.cat_tree.heading(col, text=col)
            w = 160 if col == "Medicine" else 100 if col == "Unit" else 90
            self.cat_tree.column(col, width=w, minwidth=60,
                                  anchor="w" if col == "Medicine" else "center")
        vsb = ttk.Scrollbar(left, orient="vertical", command=self.cat_tree.yview)
        self.cat_tree.configure(yscrollcommand=vsb.set)
        self.cat_tree.pack(side="left", fill="both", expand=True, padx=4, pady=4)
        vsb.pack(side="right", fill="y", pady=4)

        add_row = tk.Frame(left, bg=T["CARD"], padx=8, pady=6)
        add_row.pack(fill="x")
        tk.Label(add_row, text="Qty:", font=F_SMALL, fg=T["TEXT2"], bg=T["CARD"]).pack(side="left")
        self.qty_v = tk.StringVar(value="1")
        tk.Spinbox(add_row, from_=1, to=99, textvariable=self.qty_v,
                   font=F_BODY, width=5, bg=T["INPUT_BG"], fg=T["TEXT"], bd=0).pack(side="left", padx=6)
        RoundBtn(add_row, "➕ Add to Cart", self._add_to_cart,
                 bg=GREEN, fg=WHITE_FIXED).pack(side="left", padx=4)

        right = tk.Frame(main, bg=T["CARD"])
        right.grid(row=0, column=1, sticky="nsew")
        tk.Frame(right, bg=PINK, height=3).pack(fill="x")
        tk.Label(right, text=" 🛒 Cart", font=F_SUB,
                 fg=PINK, bg=T["CARD"]).pack(anchor="w", padx=8, pady=4)
        tk.Frame(right, bg=T["BORDER"], height=1).pack(fill="x")

        cart_cols = ["Medicine", "Qty", "Subtotal"]
        self.cart_tree = ttk.Treeview(right, columns=cart_cols, show="headings", height=14)
        for col in cart_cols:
            self.cart_tree.heading(col, text=col)
            w = 150 if col == "Medicine" else 40 if col == "Qty" else 80
            self.cart_tree.column(col, width=w, minwidth=40,
                                   anchor="w" if col == "Medicine" else "center")
        vsb2 = ttk.Scrollbar(right, orient="vertical", command=self.cart_tree.yview)
        self.cart_tree.configure(yscrollcommand=vsb2.set)
        self.cart_tree.pack(side="left", fill="both", expand=True, padx=4, pady=4)
        vsb2.pack(side="right", fill="y", pady=4)

        cart_btns = tk.Frame(right, bg=T["CARD"], padx=8, pady=6)
        cart_btns.pack(fill="x")
        RoundBtn(cart_btns, "🗑 Remove", self._remove_from_cart, bg=RED, fg=WHITE_FIXED).pack(side="left", padx=4)
        RoundBtn(cart_btns, "🗑 Clear All", self._clear_cart, bg="#6B7280", fg=WHITE_FIXED).pack(side="left", padx=4)

        tk.Frame(self, bg=T["BORDER"], height=1).pack(fill="x")
        bot = tk.Frame(self, bg=T["CARD"], padx=20, pady=12)
        bot.pack(fill="x")
        self.grand_lbl = tk.Label(bot, text="Grand Total: LKR 0.00",
                                   font=("Helvetica", 12, "bold"), fg=GREEN, bg=T["CARD"])
        self.grand_lbl.pack(side="left")
        RoundBtn(bot, "✅ Confirm & Add to Bill", self._confirm,
                 bg=GREEN, fg=WHITE_FIXED).pack(side="right", padx=4)
        RoundBtn(bot, "Cancel", self.destroy, bg="#6B7280", fg=WHITE_FIXED).pack(side="right")
        self._refresh_catalog()

    def _refresh_catalog(self):
        self.cat_tree.delete(*self.cat_tree.get_children())
        q = self.search_v.get().strip().lower()
        cat_filter = self.cat_v.get()
        for i, m in enumerate(MEDICINE_CATALOG):
            if q and q not in m["name"].lower() and q not in m["category"].lower():
                continue
            if cat_filter != "All" and m["category"] != cat_filter:
                continue
            tags = ("even",) if i % 2 == 0 else ("odd",)
            self.cat_tree.insert("", "end",
                values=(m["name"], m["unit"], f"{m['price']:.2f}", m["category"]),
                tags=tags)

    def _add_to_cart(self):
        sel = self.cat_tree.focus()
        if not sel:
            messagebox.showwarning("Select", "Select a medicine from the catalog.", parent=self)
            return
        vals = self.cat_tree.item(sel, "values")
        name = vals[0]; price = float(vals[2])
        try:
            qty = int(self.qty_v.get()); assert qty > 0
        except:
            messagebox.showerror("Error", "Enter valid quantity.", parent=self); return
        unit = next((m["unit"] for m in MEDICINE_CATALOG if m["name"] == name), "")
        if name in self.cart:
            self.cart[name]["qty"] += qty
        else:
            self.cart[name] = {"qty": qty, "price": price, "unit": unit}
        self._refresh_cart()

    def _remove_from_cart(self):
        sel = self.cart_tree.focus()
        if not sel: return
        vals = self.cart_tree.item(sel, "values")
        if vals[0] in self.cart: del self.cart[vals[0]]
        self._refresh_cart()

    def _clear_cart(self):
        self.cart.clear(); self._refresh_cart()

    def _refresh_cart(self):
        self.cart_tree.delete(*self.cart_tree.get_children())
        total = 0
        for name, info in self.cart.items():
            sub = info["qty"] * info["price"]; total += sub
            self.cart_tree.insert("", "end",
                values=(name, info["qty"], f"LKR {sub:,.2f}"))
        self.total_lbl.config(text=f"Total: LKR {total:,.2f}")
        self.grand_lbl.config(text=f"Grand Total: LKR {total:,.2f}")

    def _confirm(self):
        if not self.cart:
            messagebox.showwarning("Empty", "Cart is empty.", parent=self); return
        total = sum(v["qty"] * v["price"] for v in self.cart.values())
        items_str = ", ".join(f"{n} x{i['qty']}" for n, i in self.cart.items())
        self.on_confirm(total, items_str, dict(self.cart))  # Observer callback
        self.destroy()


# ═══════════════════════════════════════════════════════════════════════
# WELCOME SCREEN
# ═══════════════════════════════════════════════════════════════════════

class WelcomeScreen(tk.Toplevel):
    """Animated splash screen. OOP → Inheritance from tk.Toplevel."""

    def __init__(self, master, on_continue):
        super().__init__(master)
        self.overrideredirect(True)
        w, h = 720, 480
        sw = self.winfo_screenwidth(); sh = self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        self._on_continue = on_continue
        self._alpha = 0.0
        self.attributes("-alpha", 0)
        self._build()
        self._fade()

    def _build(self):
        c = tk.Canvas(self, width=720, height=480, bg="#0B1120", highlightthickness=0)
        c.pack(fill="both", expand=True)
        c.create_oval(-80, -80, 220, 220, fill="#0F1A2E", outline="")
        c.create_oval(540, 300, 800, 560, fill="#0F1A2E", outline="")
        c.create_oval(560, -50, 740, 130, fill="#1A2F50", outline="")
        c.create_oval(320, 20, 400, 100, fill=BRAND, outline="#4A90D9", width=2)
        c.create_text(360, 60, text="✚", font=("Helvetica", 28, "bold"), fill=WHITE_FIXED)
        c.create_text(360, 140, text="MEDI CARE HOSPITAL",
                      font=("Helvetica", 28, "bold"), fill=WHITE_FIXED)
        c.create_text(360, 174, text="(PVT) LTD — COLOMBO, SRI LANKA",
                      font=("Helvetica", 11), fill="#94A3B8")
        c.create_line(130, 202, 590, 202, fill="#1E293B", width=1)
        c.create_text(360, 228, text="HOSPITAL MANAGEMENT SYSTEM v7.0",
                      font=("Helvetica", 13, "bold"), fill=BRAND)
        c.create_text(360, 256,
                      text="Dark/Light Themes  ·  Charts  ·  PDF Export  ·  SMS Alerts  ·  Role-Based Access",
                      font=("Helvetica", 9), fill="#64748B")
        services = [("🏥", "Outpatient"), ("🛏", "Inpatient"),
                    ("🔬", "Laboratory"), ("💊", "Pharmacy")]
        for i, (icon, label) in enumerate(services):
            x = 130 + i * 140
            c.create_rectangle(x-56, 282, x+56, 342, fill="#1E293B", outline="#334155")
            c.create_text(x, 305, text=icon, font=("Helvetica", 16), fill=BRAND)
            c.create_text(x, 328, text=label, font=("Helvetica", 8), fill="#94A3B8")
        bf = tk.Frame(c, bg="#0B1120"); c.create_window(360, 400, window=bf)
        RoundBtn(bf, " Get Started → ", self._cont, bg=BRAND, fg=WHITE_FIXED).pack(side="left", padx=8)
        RoundBtn(bf, " Exit ", self._exit, bg="#374151", fg=WHITE_FIXED).pack(side="left")
        c.create_text(360, 448, text="v7.0 · Est. 2005 · Serving 8,000+ patients annually",
                      font=("Helvetica", 8), fill="#374151")

    def _fade(self):
        if self._alpha < 1.0:
            self._alpha = min(1.0, self._alpha + 0.06)
            self.attributes("-alpha", self._alpha)
            self.after(20, self._fade)

    def _cont(self): self.destroy(); self._on_continue()
    def _exit(self): self.master.destroy()


# ═══════════════════════════════════════════════════════════════════════
# LOGIN SCREEN
# ═══════════════════════════════════════════════════════════════════════

class LoginScreen(tk.Toplevel):
    """Secure login dialog. OOP → Inheritance + Encapsulation (attempts state)."""

    def __init__(self, master, db, on_success):
        super().__init__(master)
        self.title("Medi Care HMS v7.0 — Login")
        w, h = 500, 660
        sw = self.winfo_screenwidth(); sh = self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        self.resizable(False, False)
        self.configure(bg=WHITE_FIXED)
        self.protocol("WM_DELETE_WINDOW", master.destroy)
        self.db = db
        self.on_success = on_success
        self._attempts = 0  # Encapsulated state
        self._build()

    def _build(self):
        top = tk.Canvas(self, width=500, height=190, bg="#1E3A5F", highlightthickness=0)
        top.pack(fill="x")
        top.create_oval(205, 20, 295, 110, fill=BRAND, outline="#4A90D9", width=2)
        top.create_text(250, 65, text="✚", font=("Helvetica", 28, "bold"), fill=WHITE_FIXED)
        top.create_text(250, 136, text="MEDI CARE HOSPITAL (PVT) LTD",
                        font=("Helvetica", 12, "bold"), fill=WHITE_FIXED)
        top.create_text(250, 160, text="Hospital Management System v7.0",
                        font=("Helvetica", 9), fill="#64748B")

        frm = tk.Frame(self, bg=WHITE_FIXED, padx=52, pady=26)
        frm.pack(fill="both", expand=True)
        tk.Label(frm, text="Sign In to Your Account", font=F_HEAD,
                 fg="#0D1B2A", bg=WHITE_FIXED).pack(anchor="w", pady=(0, 4))
        tk.Label(frm, text="Enter your hospital credentials", font=F_SMALL,
                 fg="#4A6080", bg=WHITE_FIXED).pack(anchor="w", pady=(0, 18))

        user_v = tk.StringVar(); pass_v = tk.StringVar()

        def entry(label, var, show=""):
            tk.Label(frm, text=label, font=F_SUB, fg="#4A6080", bg=WHITE_FIXED).pack(anchor="w")
            e = tk.Entry(frm, textvariable=var, font=F_BODY, bg="#F0F5FF", fg="#0D1B2A",
                         bd=0, highlightthickness=1, highlightbackground="#D0E0F5",
                         highlightcolor=BRAND, insertbackground=BRAND, show=show, width=38)
            e.pack(fill="x", ipady=10, pady=(4, 14))
            return e

        ue = entry("Username", user_v)
        pe = entry("Password", pass_v, "●")
        sh_v = tk.BooleanVar()
        tk.Checkbutton(frm, text="Show password", variable=sh_v,
                       command=lambda: pe.config(show="" if sh_v.get() else "●"),
                       font=F_SMALL, fg="#4A6080", bg=WHITE_FIXED,
                       activebackground=WHITE_FIXED, cursor="hand2").pack(anchor="w", pady=(0, 14))

        self._msg = tk.Label(frm, text="", font=F_SMALL, fg=RED, bg=WHITE_FIXED)
        self._msg.pack(anchor="w")

        def login(e=None):
            u = user_v.get().strip(); p = pass_v.get().strip()
            if not u or not p:
                self._msg.config(text="⚠ Enter username and password."); return
            user = self.db.verify_login(u, p)
            if user:
                self.on_success(user); self.destroy()
            else:
                self._attempts += 1
                self._msg.config(text=f"❌ Invalid credentials. Attempt {self._attempts}/5")
                if self._attempts >= 5:
                    messagebox.showerror("Locked", "Too many failed attempts.", parent=self)
                    self.master.destroy()
                pe.delete(0, "end")

        self.bind("<Return>", login)
        RoundBtn(frm, " Sign In →", login, bg=BRAND, fg=WHITE_FIXED, width=36).pack(pady=(8, 0))
        tk.Frame(frm, bg="#D0E0F5", height=1).pack(fill="x", pady=14)

        hf = tk.Frame(frm, bg="#EEF5FF", padx=14, pady=10, bd=1, relief="solid")
        hf.pack(fill="x", pady=(0, 4))
        tk.Label(hf, text="🔑  Login Credentials", font=("Helvetica", 9, "bold"),
                 fg=BRAND, bg="#EEF5FF").pack(anchor="w", pady=(0, 6))
        try:
            users_hint = self.db.fetch("SELECT username, role FROM users ORDER BY created_at LIMIT 6")
            for u_row in users_hint:
                r = tk.Frame(hf, bg="#EEF5FF"); r.pack(fill="x", pady=1)
                icon = "👑" if u_row["role"] == "Admin" else "🩺" if u_row["role"] == "Doctor" else "👤"
                tk.Label(r, text=f"{icon} {u_row['role']:<10}",
                         font=("Courier", 9, "bold"), fg="#4A6080",
                         bg="#EEF5FF", width=12, anchor="w").pack(side="left")
                tk.Label(r, text=u_row["username"],
                         font=("Courier", 9, "bold"), fg="#0D1B2A",
                         bg="#D8E8FF", padx=6, pady=2).pack(side="left", padx=2)
                tk.Label(r, text=" / default-password",
                         font=("Courier", 8), fg="#94A3B8", bg="#EEF5FF").pack(side="left", padx=2)
        except Exception:
            tk.Label(hf, text="admin / admin123  |  doctor / doc123",
                     font=("Courier", 9), fg="#0D1B2A", bg="#EEF5FF").pack(anchor="w")
        ue.focus_set()


# ═══════════════════════════════════════════════════════════════════════
# EDIT DIALOG
# ═══════════════════════════════════════════════════════════════════════

class EditDialog(tk.Toplevel):
    """
    Generic edit dialog for any record type.

    OOP → Generics / Abstraction:
      Works for patients, doctors, appointments — ANY entity.
      The fields list is injected from outside — this class doesn't
      know or care WHAT it's editing.

    Design Pattern → Template Method:
      Always builds: header → fields → save button.
      The actual fields (content) vary per use.
    """

    def __init__(self, master, title, fields, data, on_save,
                 color=BRAND, th=None):
        super().__init__(master)
        self.title(title)
        T = th or {"WHITE": "#FFFFFF", "BG": "#F5F8FF", "TEXT": "#0D1B2A",
                   "TEXT2": "#4A6080", "BORDER": "#D0E0F5"}
        w = 520; h = 60 + len(fields) * 68 + 90
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{w}x{min(h,620)}+{(sw-w)//2}+{(sh-min(h,620))//2}")
        self.configure(bg=T["WHITE"])
        self.resizable(False, False)
        self.grab_set()

        tk.Frame(self, bg=color, height=4).pack(fill="x")
        tk.Label(self, text=title, font=F_HEAD, fg=color,
                 bg=T["WHITE"]).pack(pady=14, padx=20, anchor="w")
        tk.Frame(self, bg=T["BORDER"], height=1).pack(fill="x")

        frm = tk.Frame(self, bg=T["WHITE"], padx=24, pady=14)
        frm.pack(fill="both", expand=True)
        self._vars = {}

        for i, (key, label, typ, opts) in enumerate(fields):
            tk.Label(frm, text=label, font=F_SMALL, fg=T["TEXT2"],
                     bg=T["WHITE"]).grid(row=i*2, column=0, sticky="w", pady=(6, 2))
            var = tk.StringVar(value=str(data.get(key, "") or ""))
            self._vars[key] = var
            if typ == "combo":
                w2 = ttk.Combobox(frm, textvariable=var, values=opts,
                                   font=F_BODY, state="readonly", width=46)
            else:
                w2 = tk.Entry(frm, textvariable=var, font=F_BODY,
                              bg=T["BG"], fg=T["TEXT"], bd=0, highlightthickness=1,
                              highlightbackground=T["BORDER"], highlightcolor=color,
                              insertbackground=color, width=48)
            w2.grid(row=i*2+1, column=0, sticky="ew", pady=(0, 2))
        frm.columnconfigure(0, weight=1)

        tk.Frame(self, bg=T["BORDER"], height=1).pack(fill="x")
        br = tk.Frame(self, bg=T["WHITE"], padx=24, pady=10)
        br.pack(fill="x")

        def save():
            on_save({k: v.get().strip() for k, v in self._vars.items()})
            self.destroy()

        RoundBtn(br, "💾 Save Changes", save, bg=color, fg=WHITE_FIXED).pack(side="left", padx=4)
        RoundBtn(br, "Cancel", self.destroy, bg="#6B7280", fg=WHITE_FIXED).pack(side="left")
