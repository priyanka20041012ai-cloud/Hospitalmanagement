"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  services/appointment_service.py — AppointmentService                      ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP: Service Layer Pattern. Business logic for appointment booking,
cancellation, and status management — separate from GUI and DB.
"""

from repositories.repositories import AppointmentRepository


class AppointmentService:
    """
    Service Layer for Appointment operations.

    OOP → Encapsulation: Status-change logic is in one place.
    Design Pattern → Service Layer: GUI calls this, not the repo directly.
    SOLID → SRP: Only appointment business rules here.
    """

    VALID_STATUSES = ["Scheduled", "Completed", "Cancelled", "No-Show"]

    def __init__(self, appt_repo: AppointmentRepository):
        self._repo = appt_repo

    def book(self, patient_id: str, doctor_id: str, date: str,
             time: str, reason: str, atype: str) -> str:
        """Book a new appointment. Returns appointment_id."""
        return self._repo.add({
            "patient_id": patient_id,
            "doctor_id":  doctor_id,
            "date":       date,
            "time":       time,
            "reason":     reason,
            "atype":      atype,
        })

    def confirm(self, appointment_id: str):
        """Mark appointment as Completed."""
        self._repo.update_status(appointment_id, "Completed")

    def cancel(self, appointment_id: str):
        """Mark appointment as Cancelled."""
        self._repo.update_status(appointment_id, "Cancelled")

    def no_show(self, appointment_id: str):
        """Mark appointment as No-Show."""
        self._repo.update_status(appointment_id, "No-Show")

    def get_todays_schedule(self):
        """Get all appointments for today."""
        return self._repo.get_today()

    def get_status_summary(self) -> dict:
        """Returns count of each appointment status."""
        return self._repo.status_counts()