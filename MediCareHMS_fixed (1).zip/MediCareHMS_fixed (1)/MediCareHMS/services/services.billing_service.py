import unittest
from billing_service import BillingService

class TestBillingService(unittest.TestCase):

    def setUp(self):
        # Mock repositories (not needed for pure calculation)
        self.billing = BillingService(None, None, None)

    def test_calculate_total(self):
        result = self.billing.calculate_total(1000, 500, 100, 50, 200)
        self.assertEqual(result["total"], 1935.0)

    def test_invalid_cost(self):
        with self.assertRaises(Exception):
            self.billing.calculate_total(-100, 500, 0, 0, 0)

if __name__ == "__main__":
    unittest.main()