"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  services/doctor_service.py — DoctorService (business logic layer)          ║
╚══════════════════════════════════════════════════════════════════════════════╝

OOP Concepts:
  - Encapsulation: Doctor registration rules (valid fee, valid age, reg_no
    format) are inside this class — not scattered across the GUI.
  - SRP: Only handles doctor business rules.
  - Dependency Injection: Receives DoctorRepository via constructor.

Design Pattern → Service Layer:
  GUI calls DoctorService.register_doctor() → service validates
  → calls DoctorRepository.add() → repo runs SQL.
  This keeps GUI thin and rules centralized.
"""

from repositories.repositories import DoctorRepository


class DoctorService:
    """
    Service Layer for Doctor operations.

    OOP → Encapsulation: All validation + business rules in one class.
    SOLID → SRP: Only doctor logic. No patient, billing, or UI concerns.
    SOLID → DIP: Depends on DoctorRepository (injected), not sqlite3.
    """

    def __init__(self, doc_repo: DoctorRepository):
        self._repo = doc_repo  # Dependency Injection

    def register_doctor(self, name: str, age: int, gender: str,
                         phone: str, spec: str, fee: float,
                         regno: str) -> str:
        """
        Register a new doctor with validation.
        Returns doctor_id on success. Raises ValueError on invalid input.
        """
        name = name.strip()
        if not name:
            raise ValueError("Doctor name is required.")
        if not (18 < age < 80):
            raise ValueError("Doctor age must be between 19 and 79.")
        if fee < 0:
            raise ValueError("Consultation fee cannot be negative.")
        if not spec:
            raise ValueError("Specialization is required.")

        return self._repo.add({
            "name":   name,
            "age":    age,
            "gender": gender,
            "phone":  phone.strip(),
            "spec":   spec,
            "fee":    fee,
            "regno":  regno.strip(),
        })

    def update_doctor(self, doctor_id: str, name: str, age: int,
                       gender: str, phone: str, spec: str,
                       fee: float, regno: str):
        """Update doctor record with validation."""
        name = name.strip()
        if not name:
            raise ValueError("Doctor name is required.")
        if fee < 0:
            raise ValueError("Consultation fee cannot be negative.")

        self._repo.update(doctor_id, {
            "name":   name,
            "age":    age,
            "gender": gender,
            "phone":  phone.strip(),
            "spec":   spec,
            "fee":    fee,
            "regno":  regno.strip(),
        })

    def delete_doctor(self, doctor_id: str):
        """Delete a doctor record."""
        self._repo.delete(doctor_id)

    def get_all(self):
        """Return all doctors."""
        return self._repo.get_all()

    def get_all_with_users(self):
        """Return doctors with their linked user accounts."""
        return self._repo.get_all_with_users()

    def find_by_id(self, doctor_id: str):
        """Find a specific doctor by ID."""
        return self._repo.find_by_id(doctor_id)

    def get_by_specialization(self) -> dict:
        """
        Returns a dict mapping specialization → count.
        Used by dashboard charts.
        """
        return self._repo.by_spec()

    def get_statistics(self) -> dict:
        """Returns doctor statistics for the dashboard."""
        docs = self._repo.get_all()
        spec_map = self._repo.by_spec()
        return {
            "total":           len(docs),
            "specializations": len(spec_map),
            "by_spec":         spec_map,
        }
